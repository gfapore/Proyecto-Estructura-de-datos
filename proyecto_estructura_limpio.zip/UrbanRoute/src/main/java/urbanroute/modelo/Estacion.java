package urbanroute.modelo;
public class Estacion {
public static final String LINEA_DESCONOCIDA = "Sin línea";
public static final String ZONA_DESCONOCIDA = "Sin zona";
private final String id;
private final String nombre;
private final String linea;
private final String zona;
private final int capacidadPasajerosHora;
public Estacion(String id, String nombre, String linea, String zona, int capacidadPasajerosHora) {
this.id = id;
this.nombre = nombre;
this.linea = linea;
this.zona = zona;
this.capacidadPasajerosHora = Math.max(0, capacidadPasajerosHora);
}
public static Estacion crearGenerica(String id) {
return new Estacion(id, id, LINEA_DESCONOCIDA, ZONA_DESCONOCIDA, 0);
}
public String getId() {
return id;
}
public String getNombre() {
return nombre;
}
public String getLinea() {
return linea;
}
public String getZona() {
return zona;
}
public int getCapacidadPasajerosHora() {
return capacidadPasajerosHora;
}
@Override
public String toString() {
return nombre.equals(id) ? id : id + " - " + nombre;
}
@Override
public boolean equals(Object otro) {
return otro instanceof Estacion && ((Estacion) otro).id.equals(id);
}
@Override
public int hashCode() {
return id.hashCode();
}
}
