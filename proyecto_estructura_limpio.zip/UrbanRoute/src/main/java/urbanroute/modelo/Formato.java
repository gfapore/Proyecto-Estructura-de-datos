package urbanroute.modelo;
public final class Formato {
private Formato() {
}
public static String minutos(double minutos) {
double redondeado = Math.round(minutos * 100) / 100.0;
if (redondeado == Math.rint(redondeado)) {
return String.valueOf((long) redondeado);
}
return String.valueOf(redondeado);
}
public static String html(String texto) {
if (texto == null) {
return "";
}
StringBuilder sb = new StringBuilder(texto.length());
for (int i = 0; i < texto.length(); i++) {
char c = texto.charAt(i);
switch (c) {
case '<':
sb.append("&lt;");
break;
case '>':
sb.append("&gt;");
break;
case '&':
sb.append("&amp;");
break;
case '"':
sb.append("&quot;");
break;
default:
sb.append(c);
}
}
return sb.toString();
}
}
