package urbanroute.algoritmos;
public class InfoGrado {
private final String id;
private final int grado;
private final double centralidad;
InfoGrado(String id, int grado, double centralidad) {
this.id = id;
this.grado = grado;
this.centralidad = centralidad;
}
public String getId() {
return id;
}
public int getGrado() {
return grado;
}
public double getCentralidad() {
return centralidad;
}
}
