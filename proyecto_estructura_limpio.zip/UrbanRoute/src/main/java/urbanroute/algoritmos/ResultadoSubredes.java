package urbanroute.algoritmos;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.estructuras.Nodo;
import urbanroute.estructuras.TablaHash;
public class ResultadoSubredes {
private final ListaEnlazada<ListaEnlazada<String>> subredes = new ListaEnlazada<>();
private final TablaHash<Integer> indicePorEstacion = new TablaHash<>();
void agregarSubred(ListaEnlazada<String> subred) {
int indice = subredes.tamano();
for (Nodo<String> n = subred.getCabeza(); n != null; n = n.getSiguiente()) {
indicePorEstacion.insertar(n.getDato(), indice);
}
subredes.agregar(subred);
}
public int getCantidad() {
return subredes.tamano();
}
public ListaEnlazada<String> getSubred(int indice) {
return subredes.obtener(indice);
}
public ListaEnlazada<ListaEnlazada<String>> getSubredes() {
return subredes;
}
public int getIndiceSubred(String id) {
Integer indice = indicePorEstacion.obtener(id);
return indice == null ? -1 : indice;
}
public int contarEstacionesAisladas() {
int aisladas = 0;
for (Nodo<ListaEnlazada<String>> n = subredes.getCabeza(); n != null; n = n.getSiguiente()) {
if (n.getDato().tamano() == 1) {
aisladas++;
}
}
return aisladas;
}
}
