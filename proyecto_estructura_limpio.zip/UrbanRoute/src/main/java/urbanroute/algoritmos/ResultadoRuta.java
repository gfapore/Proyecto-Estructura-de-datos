package urbanroute.algoritmos;
public class ResultadoRuta {
private final String origen;
private final String destino;
private final String[] camino;
private final double[] tramos;
private final double tiempoTotal;
ResultadoRuta(String origen, String destino, String[] camino, double[] tramos, double tiempoTotal) {
this.origen = origen;
this.destino = destino;
this.camino = camino;
this.tramos = tramos;
this.tiempoTotal = tiempoTotal;
}
public boolean existeRuta() {
return camino != null;
}
public String getOrigen() {
return origen;
}
public String getDestino() {
return destino;
}
public String[] getCamino() {
return camino;
}
public double[] getTramos() {
return tramos;
}
public double getTiempoTotal() {
return tiempoTotal;
}
public int getParadasIntermedias() {
return camino == null ? 0 : Math.max(0, camino.length - 2);
}
}
