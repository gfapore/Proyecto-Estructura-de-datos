package urbanroute.persistencia;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.modelo.RedTransporte;
public class ResultadoCarga {
private final RedTransporte red;
private final ListaEnlazada<String> advertencias;
ResultadoCarga(RedTransporte red, ListaEnlazada<String> advertencias) {
this.red = red;
this.advertencias = advertencias;
}
public RedTransporte getRed() {
return red;
}
public ListaEnlazada<String> getAdvertencias() {
return advertencias;
}
}
