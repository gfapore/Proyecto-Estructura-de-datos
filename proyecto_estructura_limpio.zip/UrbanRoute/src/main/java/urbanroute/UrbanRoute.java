package urbanroute;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import urbanroute.interfaz.VentanaPrincipal;
public final class UrbanRoute {
private UrbanRoute() {
}
public static void main(String[] args) {
Thread.setDefaultUncaughtExceptionHandler((hilo, error) -> SwingUtilities.invokeLater(()
-> JOptionPane.showMessageDialog(null,
"Ocurrió un error inesperado, pero el programa sigue funcionando:\n" + error,
"Error", JOptionPane.ERROR_MESSAGE)));
SwingUtilities.invokeLater(() -> {
try {
UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
} catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
}
VentanaPrincipal ventana = new VentanaPrincipal();
ventana.setVisible(true);
ventana.cargarArchivoMaestro();
});
}
}
