package urbanroute.estructuras;
@FunctionalInterface
public interface Condicion<T> {
boolean cumple(T elemento);
}
