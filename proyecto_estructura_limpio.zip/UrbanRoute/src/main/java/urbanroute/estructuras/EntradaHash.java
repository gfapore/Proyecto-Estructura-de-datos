package urbanroute.estructuras;
class EntradaHash<V> {
final String clave;
V valor;
EntradaHash<V> siguiente;
EntradaHash(String clave, V valor, EntradaHash<V> siguiente) {
this.clave = clave;
this.valor = valor;
this.siguiente = siguiente;
}
}
