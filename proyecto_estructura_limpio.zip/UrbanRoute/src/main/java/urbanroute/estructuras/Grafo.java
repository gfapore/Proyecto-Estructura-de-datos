package urbanroute.estructuras;
public class Grafo {
private final TablaHash<ListaEnlazada<Arista>> listaAdyacencia = new TablaHash<>();
private final ListaEnlazada<String> vertices = new ListaEnlazada<>();
private int numAristas;
public boolean agregarVertice(String id) {
if (id == null || listaAdyacencia.contiene(id)) {
return false;
}
listaAdyacencia.insertar(id, new ListaEnlazada<>());
vertices.agregar(id);
return true;
}
public boolean eliminarVertice(String id) {
ListaEnlazada<Arista> adyacentes = listaAdyacencia.obtener(id);
if (adyacentes == null) {
return false;
}
for (Nodo<Arista> n = adyacentes.getCabeza(); n != null; n = n.getSiguiente()) {
ListaEnlazada<Arista> delVecino = listaAdyacencia.obtener(n.getDato().getDestino());
if (delVecino != null) {
delVecino.eliminarPrimero(a -> a.getDestino().equals(id));
}
numAristas--;
}
listaAdyacencia.eliminar(id);
vertices.eliminar(id);
return true;
}
public boolean agregarArista(String origen, String destino, double tiempo) {
ListaEnlazada<Arista> deOrigen = listaAdyacencia.obtener(origen);
ListaEnlazada<Arista> deDestino = listaAdyacencia.obtener(destino);
if (deOrigen == null || deDestino == null) {
throw new IllegalArgumentException("Ambas estaciones deben existir en el grafo.");
}
if (origen.equals(destino)) {
throw new IllegalArgumentException("Una estación no puede conectarse consigo misma.");
}
if (!(tiempo > 0) || Double.isInfinite(tiempo)) {
throw new IllegalArgumentException("El tiempo de traslado debe ser mayor que cero.");
}
Arista ida = buscarArista(origen, destino);
if (ida != null) {
ida.setTiempo(tiempo);
buscarArista(destino, origen).setTiempo(tiempo);
return false;
}
deOrigen.agregar(new Arista(destino, tiempo));
deDestino.agregar(new Arista(origen, tiempo));
numAristas++;
return true;
}
public boolean eliminarArista(String origen, String destino) {
ListaEnlazada<Arista> deOrigen = listaAdyacencia.obtener(origen);
ListaEnlazada<Arista> deDestino = listaAdyacencia.obtener(destino);
if (deOrigen == null || deDestino == null) {
return false;
}
boolean eliminada = deOrigen.eliminarPrimero(a -> a.getDestino().equals(destino));
if (eliminada) {
deDestino.eliminarPrimero(a -> a.getDestino().equals(origen));
numAristas--;
}
return eliminada;
}
public Arista buscarArista(String origen, String destino) {
ListaEnlazada<Arista> deOrigen = listaAdyacencia.obtener(origen);
if (deOrigen == null) {
return null;
}
return deOrigen.buscar(a -> a.getDestino().equals(destino));
}
public boolean existeArista(String origen, String destino) {
return buscarArista(origen, destino) != null;
}
public boolean existeVertice(String id) {
return listaAdyacencia.contiene(id);
}
public ListaEnlazada<Arista> obtenerAdyacentes(String id) {
ListaEnlazada<Arista> lista = listaAdyacencia.obtener(id);
return lista == null ? new ListaEnlazada<>() : lista;
}
public int grado(String id) {
ListaEnlazada<Arista> lista = listaAdyacencia.obtener(id);
return lista == null ? 0 : lista.tamano();
}
public String[] obtenerVertices() {
String[] resultado = new String[vertices.tamano()];
int i = 0;
for (Nodo<String> n = vertices.getCabeza(); n != null; n = n.getSiguiente()) {
resultado[i++] = n.getDato();
}
return resultado;
}
public ListaEnlazada<Conexion> obtenerConexiones() {
ListaEnlazada<Conexion> resultado = new ListaEnlazada<>();
TablaHash<Boolean> procesados = new TablaHash<>(vertices.tamano() * 2 + 1);
for (Nodo<String> v = vertices.getCabeza(); v != null; v = v.getSiguiente()) {
String origen = v.getDato();
for (Nodo<Arista> a = obtenerAdyacentes(origen).getCabeza(); a != null; a = a.getSiguiente()) {
if (!procesados.contiene(a.getDato().getDestino())) {
resultado.agregar(new Conexion(origen, a.getDato().getDestino(), a.getDato().getTiempo()));
}
}
procesados.insertar(origen, Boolean.TRUE);
}
return resultado;
}
public int getNumVertices() {
return vertices.tamano();
}
public int getNumAristas() {
return numAristas;
}
public void vaciar() {
listaAdyacencia.vaciar();
vertices.vaciar();
numAristas = 0;
}
}
