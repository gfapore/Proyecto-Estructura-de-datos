package urbanroute.estructuras;
public class Conexion {
private final String origen;
private final String destino;
private final double tiempo;
public Conexion(String origen, String destino, double tiempo) {
this.origen = origen;
this.destino = destino;
this.tiempo = tiempo;
}
public String getOrigen() {
return origen;
}
public String getDestino() {
return destino;
}
public double getTiempo() {
return tiempo;
}
}
