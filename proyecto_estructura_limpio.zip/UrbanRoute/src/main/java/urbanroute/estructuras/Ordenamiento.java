package urbanroute.estructuras;
public final class Ordenamiento {
private Ordenamiento() {
}
@SuppressWarnings("unchecked")
public static <T> void mergeSort(T[] arreglo, Comparador<? super T> comparador) {
if (arreglo == null || arreglo.length < 2) {
return;
}
Object[] auxiliar = new Object[arreglo.length];
ordenar(arreglo, (T[]) auxiliar, 0, arreglo.length - 1, comparador);
}
private static <T> void ordenar(T[] a, T[] aux, int inicio, int fin, Comparador<? super T> c) {
if (inicio >= fin) {
return;
}
int medio = (inicio + fin) >>> 1;
ordenar(a, aux, inicio, medio, c);
ordenar(a, aux, medio + 1, fin, c);
mezclar(a, aux, inicio, medio, fin, c);
}
private static <T> void mezclar(T[] a, T[] aux, int inicio, int medio, int fin, Comparador<? super T> c) {
for (int k = inicio; k <= fin; k++) {
aux[k] = a[k];
}
int i = inicio;
int j = medio + 1;
for (int k = inicio; k <= fin; k++) {
if (i > medio) {
a[k] = aux[j++];
} else if (j > fin) {
a[k] = aux[i++];
} else if (c.comparar(aux[j], aux[i]) < 0) {
a[k] = aux[j++];
} else {
a[k] = aux[i++];
}
}
}
}
