package urbanroute.estructuras;
public class Arista {
private final String destino;
private double tiempo;
public Arista(String destino, double tiempo) {
this.destino = destino;
this.tiempo = tiempo;
}
public String getDestino() {
return destino;
}
public double getTiempo() {
return tiempo;
}
public void setTiempo(double tiempo) {
this.tiempo = tiempo;
}
}
