package urbanroute.estructuras;
public class ListaEnlazada<T> {
private Nodo<T> cabeza;
private Nodo<T> cola;
private int tamano;
public void agregar(T dato) {
Nodo<T> nuevo = new Nodo<>(dato);
if (cabeza == null) {
cabeza = nuevo;
cola = nuevo;
} else {
cola.setSiguiente(nuevo);
cola = nuevo;
}
tamano++;
}
public void agregarAlInicio(T dato) {
Nodo<T> nuevo = new Nodo<>(dato);
nuevo.setSiguiente(cabeza);
cabeza = nuevo;
if (cola == null) {
cola = nuevo;
}
tamano++;
}
public T obtener(int indice) {
if (indice < 0 || indice >= tamano) {
throw new IndexOutOfBoundsException("Índice fuera de rango: " + indice);
}
Nodo<T> actual = cabeza;
for (int i = 0; i < indice; i++) {
actual = actual.getSiguiente();
}
return actual.getDato();
}
public T buscar(Condicion<T> condicion) {
for (Nodo<T> n = cabeza; n != null; n = n.getSiguiente()) {
if (condicion.cumple(n.getDato())) {
return n.getDato();
}
}
return null;
}
public boolean eliminar(T dato) {
return eliminarPrimero(e -> e == null ? dato == null : e.equals(dato));
}
public boolean eliminarPrimero(Condicion<T> condicion) {
Nodo<T> anterior = null;
Nodo<T> actual = cabeza;
while (actual != null) {
if (condicion.cumple(actual.getDato())) {
if (anterior == null) {
cabeza = actual.getSiguiente();
} else {
anterior.setSiguiente(actual.getSiguiente());
}
if (actual == cola) {
cola = anterior;
}
tamano--;
return true;
}
anterior = actual;
actual = actual.getSiguiente();
}
return false;
}
public boolean contiene(T dato) {
return buscar(e -> e == null ? dato == null : e.equals(dato)) != null;
}
public Nodo<T> getCabeza() {
return cabeza;
}
public int tamano() {
return tamano;
}
public boolean estaVacia() {
return tamano == 0;
}
public void vaciar() {
cabeza = null;
cola = null;
tamano = 0;
}
}
