package urbanroute.estructuras;
public class TablaHash<V> {
private static final int CAPACIDAD_INICIAL = 31;
public static final double FACTOR_CARGA_MAXIMO = 0.75;
private EntradaHash<V>[] cubetas;
private int tamano;
public TablaHash() {
this(CAPACIDAD_INICIAL);
}
public TablaHash(int capacidadInicial) {
cubetas = crearCubetas(siguientePrimo(Math.max(3, capacidadInicial)));
}
private static int funcionHash(String clave, int capacidad) {
long h = 0;
for (int i = 0; i < clave.length(); i++) {
h = (h * 31 + clave.charAt(i)) % capacidad;
}
return (int) h;
}
public void insertar(String clave, V valor) {
validarClave(clave);
int indice = funcionHash(clave, cubetas.length);
for (EntradaHash<V> e = cubetas[indice]; e != null; e = e.siguiente) {
if (e.clave.equals(clave)) {
e.valor = valor;
return;
}
}
cubetas[indice] = new EntradaHash<>(clave, valor, cubetas[indice]);
tamano++;
if (factorCarga() > FACTOR_CARGA_MAXIMO) {
redimensionar();
}
}
public V obtener(String clave) {
if (clave == null) {
return null;
}
int indice = funcionHash(clave, cubetas.length);
for (EntradaHash<V> e = cubetas[indice]; e != null; e = e.siguiente) {
if (e.clave.equals(clave)) {
return e.valor;
}
}
return null;
}
public boolean contiene(String clave) {
if (clave == null) {
return false;
}
int indice = funcionHash(clave, cubetas.length);
for (EntradaHash<V> e = cubetas[indice]; e != null; e = e.siguiente) {
if (e.clave.equals(clave)) {
return true;
}
}
return false;
}
public V eliminar(String clave) {
if (clave == null) {
return null;
}
int indice = funcionHash(clave, cubetas.length);
EntradaHash<V> anterior = null;
for (EntradaHash<V> e = cubetas[indice]; e != null; e = e.siguiente) {
if (e.clave.equals(clave)) {
if (anterior == null) {
cubetas[indice] = e.siguiente;
} else {
anterior.siguiente = e.siguiente;
}
tamano--;
return e.valor;
}
anterior = e;
}
return null;
}
public String[] claves() {
String[] resultado = new String[tamano];
int k = 0;
for (EntradaHash<V> cabeza : cubetas) {
for (EntradaHash<V> e = cabeza; e != null; e = e.siguiente) {
resultado[k++] = e.clave;
}
}
return resultado;
}
public ListaEnlazada<V> valores() {
ListaEnlazada<V> resultado = new ListaEnlazada<>();
for (EntradaHash<V> cabeza : cubetas) {
for (EntradaHash<V> e = cabeza; e != null; e = e.siguiente) {
resultado.agregar(e.valor);
}
}
return resultado;
}
public void vaciar() {
cubetas = crearCubetas(cubetas.length);
tamano = 0;
}
public int tamano() {
return tamano;
}
public boolean estaVacia() {
return tamano == 0;
}
public int capacidad() {
return cubetas.length;
}
public double factorCarga() {
return (double) tamano / cubetas.length;
}
public int cubetasOcupadas() {
int ocupadas = 0;
for (EntradaHash<V> cabeza : cubetas) {
if (cabeza != null) {
ocupadas++;
}
}
return ocupadas;
}
public int longitudCadenaMasLarga() {
int maximo = 0;
for (EntradaHash<V> cabeza : cubetas) {
int longitud = 0;
for (EntradaHash<V> e = cabeza; e != null; e = e.siguiente) {
longitud++;
}
if (longitud > maximo) {
maximo = longitud;
}
}
return maximo;
}
public int colisiones() {
return tamano - cubetasOcupadas();
}
private void redimensionar() {
EntradaHash<V>[] anteriores = cubetas;
cubetas = crearCubetas(siguientePrimo(anteriores.length * 2 + 1));
for (EntradaHash<V> cabeza : anteriores) {
EntradaHash<V> e = cabeza;
while (e != null) {
EntradaHash<V> siguiente = e.siguiente;
int indice = funcionHash(e.clave, cubetas.length);
e.siguiente = cubetas[indice];
cubetas[indice] = e;
e = siguiente;
}
}
}
@SuppressWarnings({"unchecked", "rawtypes"})
private EntradaHash<V>[] crearCubetas(int capacidad) {
return (EntradaHash<V>[]) new EntradaHash[capacidad];
}
private static void validarClave(String clave) {
if (clave == null) {
throw new IllegalArgumentException("La clave de la tabla hash no puede ser nula.");
}
}
private static int siguientePrimo(int n) {
int candidato = Math.max(2, n);
while (!esPrimo(candidato)) {
candidato++;
}
return candidato;
}
private static boolean esPrimo(int n) {
if (n < 2) {
return false;
}
if (n % 2 == 0) {
return n == 2;
}
for (int d = 3; (long) d * d <= n; d += 2) {
if (n % d == 0) {
return false;
}
}
return true;
}
}
