package urbanroute.estructuras;
public class Cola<T> {
private Nodo<T> frente;
private Nodo<T> fin;
private int tamano;
public void encolar(T dato) {
Nodo<T> nuevo = new Nodo<>(dato);
if (fin == null) {
frente = nuevo;
} else {
fin.setSiguiente(nuevo);
}
fin = nuevo;
tamano++;
}
public T desencolar() {
if (frente == null) {
throw new IllegalStateException("La cola está vacía.");
}
T dato = frente.getDato();
frente = frente.getSiguiente();
if (frente == null) {
fin = null;
}
tamano--;
return dato;
}
public boolean estaVacia() {
return tamano == 0;
}
public int tamano() {
return tamano;
}
}
