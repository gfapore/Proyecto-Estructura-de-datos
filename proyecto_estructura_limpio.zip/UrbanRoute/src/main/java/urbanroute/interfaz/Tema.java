package urbanroute.interfaz;
import java.awt.Color;
import java.awt.Font;
public final class Tema {
public static final Color FONDO = new Color(0xF3F5F9);
public static final Color LATERAL = new Color(0x18222F);
public static final Color LATERAL_BOTON = new Color(0x223044);
public static final Color LATERAL_BOTON_HOVER = new Color(0x2D3F58);
public static final Color LATERAL_TEXTO = new Color(0xE6ECF4);
public static final Color LATERAL_TITULO = new Color(0x7F93AD);
public static final Color ACENTO = new Color(0x2F80ED);
public static final Color ACENTO_HOVER = new Color(0x1C6CD6);
public static final Color PELIGRO = new Color(0xD64545);
public static final Color PELIGRO_HOVER = new Color(0xB93636);
public static final Color RUTA = new Color(0xF2994A);
public static final Color HUB = new Color(0xE8B10E);
public static final Color ARISTA = new Color(0xB9C2CE);
public static final Color TEXTO = new Color(0x1F2937);
public static final Color TEXTO_SECUNDARIO = new Color(0x6B7280);
public static final Color BORDE = new Color(0xDDE3EA);
public static final Font FUENTE = new Font("Segoe UI", Font.PLAIN, 13);
public static final Font FUENTE_NEGRITA = new Font("Segoe UI", Font.BOLD, 13);
public static final Font FUENTE_PEQUENA = new Font("Segoe UI", Font.PLAIN, 11);
public static final Font FUENTE_TITULO = new Font("Segoe UI", Font.BOLD, 20);
private static final Color[] PALETA = {
new Color(0x2F80ED), new Color(0xEB5757), new Color(0x27AE60), new Color(0x9B51E0),
new Color(0xF2994A), new Color(0x00A3A3), new Color(0xD6409F), new Color(0x8D6E63),
new Color(0x5C6BC0), new Color(0x7CB342)
};
private Tema() {
}
public static Color colorCategoria(int indice) {
if (indice < 0) {
return Color.GRAY;
}
if (indice < PALETA.length) {
return PALETA[indice];
}
float tono = (float) ((indice * 0.618033988749895) % 1.0);
return Color.getHSBColor(tono, 0.55f, 0.80f);
}
public static Color oscurecer(Color c) {
return new Color((int) (c.getRed() * 0.7), (int) (c.getGreen() * 0.7), (int) (c.getBlue() * 0.7));
}
public static String hex(Color c) {
return String.format("#%02X%02X%02X", c.getRed(), c.getGreen(), c.getBlue());
}
}
