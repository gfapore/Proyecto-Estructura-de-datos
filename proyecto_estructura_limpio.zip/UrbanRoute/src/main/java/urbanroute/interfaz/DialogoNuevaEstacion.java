package urbanroute.interfaz;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import urbanroute.estructuras.Arista;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.modelo.Estacion;
import urbanroute.modelo.Formato;
import urbanroute.modelo.RedTransporte;
public class DialogoNuevaEstacion extends JDialog {
private final RedTransporte red;
private final JTextField campoId = new JTextField(14);
private final JTextField campoNombre = new JTextField(14);
private final JComboBox<String> comboLinea;
private final JComboBox<String> comboZona;
private final JSpinner spinnerCapacidad = new JSpinner(new SpinnerNumberModel(10000, 0, 1000000, 500));
private final JComboBox<Estacion> comboVecina;
private final JSpinner spinnerTiempo = new JSpinner(new SpinnerNumberModel(2.0, 0.5, 999.0, 0.5));
private final DefaultListModel<String> modeloConexiones = new DefaultListModel<>();
private final JList<String> listaConexiones = new JList<>(modeloConexiones);
private final ListaEnlazada<Arista> conexiones = new ListaEnlazada<>();
private Estacion resultado;
public DialogoNuevaEstacion(Frame padre, RedTransporte red) {
super(padre, "Agregar estación", true);
this.red = red;
comboLinea = new JComboBox<>(red.obtenerLineas());
comboLinea.setEditable(true);
comboZona = new JComboBox<>(red.obtenerZonas());
comboZona.setEditable(true);
comboVecina = new JComboBox<>(red.obtenerEstacionesOrdenadas());
JPanel datos = Dialogos.formulario(
new String[]{"ID (único, ej. LPE):", "Nombre:", "Línea:", "Zona:", "Capacidad (pas/h):"},
new JComponent[]{campoId, campoNombre, comboLinea, comboZona, spinnerCapacidad});
datos.setBorder(BorderFactory.createTitledBorder("1. Datos de la estación"));
JPanel conex = new JPanel(new BorderLayout(6, 6));
conex.setBorder(BorderFactory.createTitledBorder("2. Conexiones con estaciones existentes"));
JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
fila.add(new JLabel("Estación:"));
comboVecina.setPreferredSize(new Dimension(220, comboVecina.getPreferredSize().height));
fila.add(comboVecina);
fila.add(new JLabel("Min:"));
fila.add(spinnerTiempo);
JButton agregar = new JButton("Añadir");
agregar.addActionListener(e -> agregarConexion());
fila.add(agregar);
JButton quitar = new JButton("Quitar seleccionada");
quitar.addActionListener(e -> quitarConexion());
listaConexiones.setVisibleRowCount(5);
conex.add(fila, BorderLayout.NORTH);
conex.add(new JScrollPane(listaConexiones), BorderLayout.CENTER);
conex.add(quitar, BorderLayout.SOUTH);
if (comboVecina.getItemCount() == 0) {
agregar.setEnabled(false);
comboVecina.setEnabled(false);
}
JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
JButton cancelar = new JButton("Cancelar");
cancelar.addActionListener(e -> dispose());
JButton aceptar = new JButton("Agregar estación");
aceptar.addActionListener(e -> aceptar());
botones.add(cancelar);
botones.add(aceptar);
getRootPane().setDefaultButton(aceptar);
JPanel contenido = new JPanel(new BorderLayout(8, 8));
contenido.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
contenido.add(datos, BorderLayout.NORTH);
contenido.add(conex, BorderLayout.CENTER);
contenido.add(botones, BorderLayout.SOUTH);
setContentPane(contenido);
pack();
setMinimumSize(getSize());
setLocationRelativeTo(padre);
}
public Estacion mostrar() {
setVisible(true);
return resultado;
}
public ListaEnlazada<Arista> getConexiones() {
return conexiones;
}
private void agregarConexion() {
Estacion vecina = (Estacion) comboVecina.getSelectedItem();
if (vecina == null) {
return;
}
double minutos = ((Number) spinnerTiempo.getValue()).doubleValue();
Arista existente = conexiones.buscar(a -> a.getDestino().equals(vecina.getId()));
String texto = vecina + "  —  " + Formato.minutos(minutos) + " min";
if (existente != null) {
existente.setTiempo(minutos);
for (int i = 0; i < conexiones.tamano(); i++) {
if (conexiones.obtener(i) == existente) {
modeloConexiones.set(i, texto);
}
}
return;
}
conexiones.agregar(new Arista(vecina.getId(), minutos));
modeloConexiones.addElement(texto);
}
private void quitarConexion() {
int indice = listaConexiones.getSelectedIndex();
if (indice < 0) {
Dialogos.error(this, "Seleccione en la lista la conexión que desea quitar.");
return;
}
Arista a = conexiones.obtener(indice);
conexiones.eliminarPrimero(x -> x == a);
modeloConexiones.remove(indice);
}
private void aceptar() {
String id = campoId.getText().trim().toUpperCase();
String nombre = campoNombre.getText().trim();
String linea = textoCombo(comboLinea);
String zona = textoCombo(comboZona);
if (id.isEmpty() || nombre.isEmpty() || linea.isEmpty() || zona.isEmpty()) {
Dialogos.error(this, "Complete el ID, el nombre, la línea y la zona.");
return;
}
if (contieneSeparador(id) || contieneSeparador(nombre) || contieneSeparador(linea) || contieneSeparador(zona)) {
Dialogos.error(this, "Los datos no pueden contener comas (,) porque se guardan en formato CSV.");
return;
}
if (id.contains(" ")) {
Dialogos.error(this, "El ID no puede contener espacios. Use guion bajo, por ejemplo: LA_PAZ.");
return;
}
if (red.existeId(id)) {
Dialogos.error(this, "Ya existe una estación con el ID \"" + id + "\".");
return;
}
if (red.existeNombre(nombre)) {
Dialogos.error(this, "Ya existe una estación llamada \"" + nombre + "\".");
return;
}
if (conexiones.estaVacia()) {
int r = JOptionPane.showConfirmDialog(this,
"La estación no tiene conexiones y quedará aislada.\n¿Desea agregarla de todas formas?",
"Estación sin conexiones", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
if (r != JOptionPane.YES_OPTION) {
return;
}
}
int capacidad = ((Number) spinnerCapacidad.getValue()).intValue();
resultado = new Estacion(id, nombre, linea, zona, capacidad);
dispose();
}
private static String textoCombo(JComboBox<String> combo) {
Object valor = combo.getEditor().getItem();
return valor == null ? "" : valor.toString().trim();
}
private static boolean contieneSeparador(String texto) {
return texto.indexOf(',') >= 0 || texto.indexOf('\n') >= 0;
}
}
