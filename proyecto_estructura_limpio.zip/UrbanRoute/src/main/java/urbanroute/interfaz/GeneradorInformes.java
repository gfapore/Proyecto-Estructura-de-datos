package urbanroute.interfaz;
import urbanroute.algoritmos.AnalizadorRed;
import urbanroute.algoritmos.InfoGrado;
import urbanroute.algoritmos.ResultadoRuta;
import urbanroute.algoritmos.ResultadoSubredes;
import urbanroute.estructuras.Arista;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.estructuras.Nodo;
import urbanroute.estructuras.TablaHash;
import urbanroute.modelo.Estacion;
import urbanroute.modelo.Formato;
import urbanroute.modelo.RedTransporte;
public final class GeneradorInformes {
private static final int FILAS_RANKING = 10;
private GeneradorInformes() {
}
public static String bienvenida() {
return abrir("Cómo usar UrbanRoute")
+ "<p>La red se muestra como un grafo: cada círculo es una estación y cada línea una "
+ "conexión con su tiempo de traslado en minutos.</p>"
+ "<p><b>En el grafo</b></p><ul>"
+ "<li>Clic en una estación: ver su ficha.</li>"
+ "<li>Rueda del ratón: acercar / alejar.</li>"
+ "<li>Arrastrar el fondo: mover la vista.</li>"
+ "<li>Arrastrar una estación: reubicarla.</li></ul>"
+ "<p><b>Análisis</b></p><ul>"
+ "<li><b>Subredes</b>: zonas que quedan conectadas entre sí (BFS).</li>"
+ "<li><b>Ruta más rápida</b>: menor tiempo entre A y B (Dijkstra).</li>"
+ "<li><b>Hubs</b>: estaciones con más conexiones directas.</li></ul>"
+ "<p>Los cambios a la red se guardan en el archivo con <b>Actualizar repositorio</b>.</p>"
+ cerrar();
}
public static String fichaEstacion(RedTransporte red, String id, ResultadoSubredes subredes) {
Estacion e = red.obtenerEstacion(id);
if (e == null) {
return abrir("Estación no encontrada") + "<p>La estación ya no existe en la red.</p>" + cerrar();
}
StringBuilder sb = new StringBuilder(abrir(Formato.html(e.getNombre())));
sb.append("<table cellpadding='3'>")
.append(fila("ID", e.getId()))
.append(fila("Línea", e.getLinea()))
.append(fila("Zona", e.getZona()))
.append(fila("Capacidad", e.getCapacidadPasajerosHora() + " pasajeros/hora"))
.append(fila("Grado", String.valueOf(red.getGrafo().grado(id))));
if (subredes != null && subredes.getIndiceSubred(id) >= 0) {
sb.append(fila("Subred", "N.º " + (subredes.getIndiceSubred(id) + 1)));
}
sb.append("</table><p><b>Conexiones directas</b></p>");
ListaEnlazada<Arista> ady = red.getGrafo().obtenerAdyacentes(id);
if (ady.estaVacia()) {
sb.append("<p style='color:#D64545'>Estación aislada: no tiene conexiones.</p>");
} else {
sb.append("<ul>");
for (Nodo<Arista> n = ady.getCabeza(); n != null; n = n.getSiguiente()) {
Estacion v = red.obtenerEstacion(n.getDato().getDestino());
sb.append("<li>").append(Formato.html(v == null ? n.getDato().getDestino() : v.toString()))
.append(" — ").append(Formato.minutos(n.getDato().getTiempo())).append(" min</li>");
}
sb.append("</ul>");
}
return sb.append(cerrar()).toString();
}
public static String subredes(RedTransporte red, ResultadoSubredes subredes, String aviso) {
StringBuilder sb = new StringBuilder(abrir("Subredes conexas"));
sb.append(avisoHtml(aviso));
int cantidad = subredes.getCantidad();
if (cantidad == 0) {
return sb.append("<p>No hay estaciones en la red.</p>").append(cerrar()).toString();
}
if (cantidad == 1) {
sb.append("<p style='color:#27AE60'><b>La red está totalmente conectada.</b> "
+ "Desde cualquier estación se puede llegar a cualquier otra.</p>");
} else {
sb.append("<p>La red está dividida en <b>").append(cantidad).append(" subredes</b> aisladas entre sí. ")
.append("No es posible viajar de una subred a otra.</p>");
int aisladas = subredes.contarEstacionesAisladas();
if (aisladas > 0) {
sb.append("<p style='color:#D64545'>").append(aisladas)
.append(aisladas == 1 ? " estación está" : " estaciones están")
.append(" totalmente incomunicada(s).</p>");
}
}
int i = 0;
for (Nodo<ListaEnlazada<String>> n = subredes.getSubredes().getCabeza(); n != null; n = n.getSiguiente(), i++) {
ListaEnlazada<String> s = n.getDato();
sb.append("<p><font color='").append(Tema.hex(Tema.colorCategoria(i))).append("'>&#9679;</font> <b>Subred ")
.append(i + 1).append("</b> (").append(s.tamano()).append(s.tamano() == 1 ? " estación" : " estaciones")
.append(")<br><font color='#6B7280'>");
boolean primero = true;
for (Nodo<String> v = s.getCabeza(); v != null; v = v.getSiguiente()) {
sb.append(primero ? "" : ", ").append(Formato.html(v.getDato()));
primero = false;
}
sb.append("</font></p>");
}
return sb.append(cerrar()).toString();
}
public static String ruta(RedTransporte red, ResultadoRuta ruta, String aviso) {
StringBuilder sb = new StringBuilder(abrir("Ruta de menor tiempo"));
sb.append(avisoHtml(aviso));
sb.append("<p><b>Desde:</b> ").append(nombre(red, ruta.getOrigen()))
.append("<br><b>Hasta:</b> ").append(nombre(red, ruta.getDestino())).append("</p>");
if (!ruta.existeRuta()) {
return sb.append("<p style='color:#D64545'><b>No existe ruta.</b> Las estaciones están en subredes "
+ "distintas: no hay ningún trayecto que las conecte.</p>").append(cerrar()).toString();
}
sb.append("<p style='font-size:15pt; color:#F2994A'><b>").append(Formato.minutos(ruta.getTiempoTotal()))
.append(" minutos</b></p><p>").append(ruta.getCamino().length - 1).append(" tramos · ")
.append(ruta.getParadasIntermedias()).append(" paradas intermedias</p>");
String[] camino = ruta.getCamino();
double[] tramos = ruta.getTramos();
double acumulado = 0;
sb.append("<table cellpadding='3'><tr><td><b>#</b></td><td><b>Estación</b></td><td align='right'><b>Min</b></td></tr>");
for (int i = 0; i < camino.length; i++) {
if (i > 0) {
acumulado += tramos[i - 1];
}
sb.append("<tr><td>").append(i + 1).append("</td><td>").append(nombre(red, camino[i]))
.append("</td><td align='right'>").append(Formato.minutos(acumulado)).append("</td></tr>");
}
return sb.append("</table><p><font color='#6B7280'>Min = tiempo acumulado desde el origen.</font></p>")
.append(cerrar()).toString();
}
public static String hubs(RedTransporte red, InfoGrado[] ranking, String[] hubs) {
StringBuilder sb = new StringBuilder(abrir("Hubs de transferencia"));
if (hubs.length == 0) {
return sb.append("<p>La red no tiene conexiones, por lo que no hay hubs.</p>").append(cerrar()).toString();
}
int subredesActuales = AnalizadorRed.detectarSubredes(red.getGrafo()).getCantidad();
sb.append("<p>Grado máximo de la red: <b>").append(ranking[0].getGrado()).append(" conexiones</b>.</p>");
TablaHash<Boolean> esHub = new TablaHash<>();
for (String h : hubs) {
esHub.insertar(h, Boolean.TRUE);
int tras = AnalizadorRed.subredesTrasCierre(red.getGrafo(), h);
sb.append("<p><font color='#E8B10E'>&#9733;</font> <b>").append(nombre(red, h)).append("</b><br>")
.append("<font color='#6B7280'>Si colapsa, la red pasa de ").append(subredesActuales)
.append(" a <b>").append(tras).append("</b> subredes.</font></p>");
}
sb.append("<p><b>Ranking por grado</b></p><table cellpadding='3'>")
.append("<tr><td><b>#</b></td><td><b>Estación</b></td><td align='right'><b>Grado</b></td>")
.append("<td align='right'><b>Centr.</b></td></tr>");
int filas = Math.min(FILAS_RANKING, ranking.length);
for (int i = 0; i < filas; i++) {
InfoGrado g = ranking[i];
String estilo = esHub.contiene(g.getId()) ? " bgcolor='#FFF6DA'" : "";
sb.append("<tr").append(estilo).append("><td>").append(i + 1).append("</td><td>")
.append(Formato.html(g.getId())).append("</td><td align='right'>").append(g.getGrado())
.append("</td><td align='right'>").append(String.format("%.3f", g.getCentralidad())).append("</td></tr>");
}
return sb.append("</table><p><font color='#6B7280'>Centr. = grado / (n − 1).</font></p>")
.append(cerrar()).toString();
}
public static String estadisticasHash(RedTransporte red) {
TablaHash<Estacion> t = red.getIndiceEstaciones();
return abrir("Tabla hash de estaciones")
+ "<p>Clave: ID de la estación → objeto Estacion.<br>"
+ "Dispersión polinomial base 31 (Horner) y colisiones por encadenamiento separado.</p>"
+ "<table cellpadding='3'>"
+ fila("Elementos", String.valueOf(t.tamano()))
+ fila("Cubetas (primo)", String.valueOf(t.capacidad()))
+ fila("Factor de carga", String.format("%.2f (máx. %.2f)", t.factorCarga(), TablaHash.FACTOR_CARGA_MAXIMO))
+ fila("Cubetas ocupadas", String.valueOf(t.cubetasOcupadas()))
+ fila("Colisiones", String.valueOf(t.colisiones()))
+ fila("Cadena más larga", String.valueOf(t.longitudCadenaMasLarga()))
+ "</table>" + cerrar();
}
private static String nombre(RedTransporte red, String id) {
Estacion e = red.obtenerEstacion(id);
return Formato.html(e == null ? id : e.toString());
}
private static String fila(String clave, String valor) {
return "<tr><td><font color='#6B7280'>" + Formato.html(clave) + "</font></td><td><b>"
+ Formato.html(valor) + "</b></td></tr>";
}
private static String avisoHtml(String aviso) {
if (aviso == null || aviso.isEmpty()) {
return "";
}
return "<table width='100%' cellpadding='6'><tr><td bgcolor='#EAF2FE'>" + Formato.html(aviso)
+ "</td></tr></table>";
}
private static String abrir(String titulo) {
return "<html><body style='font-family:Segoe UI, sans-serif; font-size:11pt; color:#1F2937; margin:8px'>"
+ "<p style='font-size:14pt; color:#2F80ED'><b>" + titulo + "</b></p>";
}
private static String cerrar() {
return "</body></html>";
}
}
