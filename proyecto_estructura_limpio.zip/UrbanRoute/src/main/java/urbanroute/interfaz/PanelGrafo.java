package urbanroute.interfaz;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.util.Random;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;
import urbanroute.algoritmos.AnalizadorRed;
import urbanroute.algoritmos.ResultadoSubredes;
import urbanroute.estructuras.Arista;
import urbanroute.estructuras.Conexion;
import urbanroute.estructuras.Grafo;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.estructuras.Nodo;
import urbanroute.estructuras.TablaHash;
import urbanroute.modelo.Estacion;
import urbanroute.modelo.Formato;
import urbanroute.modelo.RedTransporte;
public class PanelGrafo extends JPanel {
public enum ModoColor {
POR_SUBRED("Colorear por subred"),
POR_LINEA("Colorear por línea");
private final String texto;
ModoColor(String texto) {
this.texto = texto;
}
@Override
public String toString() {
return texto;
}
}
public interface OyenteSeleccion {
void estacionSeleccionada(String id);
}
private static final double RADIO_BASE = 13;
private static final double LONGITUD_IDEAL = 70;
private static final int MAX_LEYENDA = 10;
private RedTransporte red;
private TablaHash<double[]> posiciones = new TablaHash<>();
private ResultadoSubredes subredes;
private TablaHash<Integer> colorLinea = new TablaHash<>();
private String[] lineas = new String[0];
private TablaHash<Boolean> nodosRuta = new TablaHash<>();
private TablaHash<Boolean> aristasRuta = new TablaHash<>();
private TablaHash<Boolean> nodosHub = new TablaHash<>();
private String seleccionada;
private ModoColor modoColor = ModoColor.POR_SUBRED;
private double escala = 1;
private double desplazamientoX;
private double desplazamientoY;
private boolean ajustePendiente = true;
private String nodoArrastrado;
private Point ultimoRaton;
private boolean huboArrastre;
private OyenteSeleccion oyente;
public PanelGrafo() {
setBackground(Color.WHITE);
ToolTipManager.sharedInstance().registerComponent(this);
MouseAdapter raton = new MouseAdapter() {
@Override
public void mousePressed(MouseEvent e) {
ultimoRaton = e.getPoint();
nodoArrastrado = nodoEn(e.getPoint());
huboArrastre = false;
}
@Override
public void mouseDragged(MouseEvent e) {
if (ultimoRaton == null) {
return;
}
double dx = e.getX() - ultimoRaton.x;
double dy = e.getY() - ultimoRaton.y;
if (nodoArrastrado != null) {
double[] p = posiciones.obtener(nodoArrastrado);
if (p != null) {
p[0] += dx / escala;
p[1] += dy / escala;
}
} else {
desplazamientoX += dx;
desplazamientoY += dy;
setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
}
ultimoRaton = e.getPoint();
huboArrastre = true;
repaint();
}
@Override
public void mouseReleased(MouseEvent e) {
if (!huboArrastre) {
String id = nodoEn(e.getPoint());
seleccionada = id;
if (id != null && oyente != null) {
oyente.estacionSeleccionada(id);
}
repaint();
}
nodoArrastrado = null;
ultimoRaton = null;
setCursor(Cursor.getDefaultCursor());
}
@Override
public void mouseMoved(MouseEvent e) {
setCursor(nodoEn(e.getPoint()) != null
? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());
}
@Override
public void mouseWheelMoved(MouseWheelEvent e) {
double factor = Math.pow(1.12, -e.getPreciseWheelRotation());
aplicarZoom(factor, e.getX(), e.getY());
}
};
addMouseListener(raton);
addMouseMotionListener(raton);
addMouseWheelListener(raton);
}
public void setOyenteSeleccion(OyenteSeleccion oyente) {
this.oyente = oyente;
}
public void setRed(RedTransporte red) {
this.red = red;
posiciones = new TablaHash<>();
seleccionada = null;
limpiarResaltados();
recalcular();
calcularDisposicion();
ajustePendiente = true;
repaint();
}
public void actualizarRed() {
if (red == null) {
return;
}
for (String id : posiciones.claves()) {
if (!red.existeId(id)) {
posiciones.eliminar(id);
}
}
if (seleccionada != null && !red.existeId(seleccionada)) {
seleccionada = null;
}
boolean hayNuevas = false;
for (String id : red.getGrafo().obtenerVertices()) {
if (!posiciones.contiene(id)) {
ubicarNueva(id);
hayNuevas = true;
}
}
recalcular();
if (hayNuevas) {
ajustePendiente = true;
}
repaint();
}
public void redistribuir() {
posiciones = new TablaHash<>();
calcularDisposicion();
ajustePendiente = true;
repaint();
}
public void setModoColor(ModoColor modo) {
this.modoColor = modo;
repaint();
}
public ResultadoSubredes getSubredes() {
return subredes;
}
public void resaltarRuta(String[] camino) {
nodosRuta = new TablaHash<>();
aristasRuta = new TablaHash<>();
if (camino != null) {
for (int i = 0; i < camino.length; i++) {
nodosRuta.insertar(camino[i], Boolean.TRUE);
if (i > 0) {
aristasRuta.insertar(claveArista(camino[i - 1], camino[i]), Boolean.TRUE);
}
}
}
repaint();
}
public void resaltarHubs(String[] ids) {
nodosHub = new TablaHash<>();
for (String id : ids) {
nodosHub.insertar(id, Boolean.TRUE);
}
repaint();
}
public void limpiarResaltados() {
nodosRuta = new TablaHash<>();
aristasRuta = new TablaHash<>();
nodosHub = new TablaHash<>();
repaint();
}
public void seleccionarYCentrar(String id) {
double[] p = posiciones.obtener(id);
if (p == null) {
return;
}
seleccionada = id;
desplazamientoX = getWidth() / 2.0 - p[0] * escala;
desplazamientoY = getHeight() / 2.0 - p[1] * escala;
repaint();
}
public void aplicarZoom(double factor, double cx, double cy) {
double nuevaEscala = Math.max(0.15, Math.min(5, escala * factor));
double mundoX = (cx - desplazamientoX) / escala;
double mundoY = (cy - desplazamientoY) / escala;
escala = nuevaEscala;
desplazamientoX = cx - mundoX * escala;
desplazamientoY = cy - mundoY * escala;
repaint();
}
public void ajustarVista() {
if (red == null || red.getNumEstaciones() == 0 || getWidth() <= 0) {
return;
}
double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
for (String id : red.getGrafo().obtenerVertices()) {
double[] p = posiciones.obtener(id);
if (p != null) {
minX = Math.min(minX, p[0]);
minY = Math.min(minY, p[1]);
maxX = Math.max(maxX, p[0]);
maxY = Math.max(maxY, p[1]);
}
}
if (minX == Double.MAX_VALUE) {
return;
}
double margen = 70;
double ancho = Math.max(1, maxX - minX);
double alto = Math.max(1, maxY - minY);
escala = Math.min((getWidth() - 2 * margen) / ancho, (getHeight() - 2 * margen) / alto);
escala = Math.max(0.15, Math.min(1.8, escala));
desplazamientoX = getWidth() / 2.0 - (minX + maxX) / 2.0 * escala;
desplazamientoY = getHeight() / 2.0 - (minY + maxY) / 2.0 * escala;
repaint();
}
private void recalcular() {
if (red == null) {
return;
}
subredes = AnalizadorRed.detectarSubredes(red.getGrafo());
colorLinea = new TablaHash<>();
Estacion[] estaciones = red.obtenerEstaciones();
String[] temporal = new String[estaciones.length];
int cantidad = 0;
for (Estacion e : estaciones) {
if (!colorLinea.contiene(e.getLinea())) {
colorLinea.insertar(e.getLinea(), cantidad);
temporal[cantidad++] = e.getLinea();
}
}
lineas = new String[cantidad];
for (int i = 0; i < cantidad; i++) {
lineas[i] = temporal[i];
}
}
private void calcularDisposicion() {
if (red == null) {
return;
}
Grafo grafo = red.getGrafo();
String[] ids = grafo.obtenerVertices();
int n = ids.length;
if (n == 0) {
return;
}
TablaHash<Integer> indice = new TablaHash<>(n * 2 + 1);
double[] x = new double[n];
double[] y = new double[n];
Random azar = new Random(7);
int k = 0;
ResultadoSubredes comp = AnalizadorRed.detectarSubredes(grafo);
for (Nodo<ListaEnlazada<String>> s = comp.getSubredes().getCabeza(); s != null; s = s.getSiguiente()) {
for (Nodo<String> v = s.getDato().getCabeza(); v != null; v = v.getSiguiente()) {
indice.insertar(v.getDato(), k);
double angulo = k * 0.55;
double radio = 20 + 9 * k;
x[k] = Math.cos(angulo) * radio + azar.nextDouble();
y[k] = Math.sin(angulo) * radio + azar.nextDouble();
k++;
}
}
int m = grafo.getNumAristas();
int[] origen = new int[m];
int[] destino = new int[m];
int e = 0;
for (Nodo<Conexion> c = grafo.obtenerConexiones().getCabeza(); c != null && e < m; c = c.getSiguiente()) {
origen[e] = indice.obtener(c.getDato().getOrigen());
destino[e] = indice.obtener(c.getDato().getDestino());
e++;
}
double kIdeal = LONGITUD_IDEAL;
double temperatura = kIdeal * Math.sqrt(n);
int iteraciones = n > 400 ? 150 : 600;
double enfriamiento = Math.pow(0.5 / temperatura, 1.0 / iteraciones);
double[] dx = new double[n];
double[] dy = new double[n];
for (int it = 0; it < iteraciones; it++) {
for (int i = 0; i < n; i++) {
dx[i] = 0;
dy[i] = 0;
}
for (int i = 0; i < n; i++) {
for (int j = i + 1; j < n; j++) {
double ddx = x[i] - x[j];
double ddy = y[i] - y[j];
double d2 = ddx * ddx + ddy * ddy;
if (d2 < 0.01) {
ddx = azar.nextDouble() - 0.5;
ddy = azar.nextDouble() - 0.5;
d2 = 0.01;
}
double fuerza = kIdeal * kIdeal / d2;
dx[i] += ddx * fuerza;
dy[i] += ddy * fuerza;
dx[j] -= ddx * fuerza;
dy[j] -= ddy * fuerza;
}
}
for (int a = 0; a < e; a++) {
int i = origen[a];
int j = destino[a];
double ddx = x[i] - x[j];
double ddy = y[i] - y[j];
double d = Math.sqrt(ddx * ddx + ddy * ddy) + 0.01;
double fuerza = d / kIdeal;
dx[i] -= ddx * fuerza;
dy[i] -= ddy * fuerza;
dx[j] += ddx * fuerza;
dy[j] += ddy * fuerza;
}
for (int i = 0; i < n; i++) {
dx[i] -= x[i] * 0.04;
dy[i] -= y[i] * 0.04;
double d = Math.sqrt(dx[i] * dx[i] + dy[i] * dy[i]);
if (d > 0) {
double paso = Math.min(d, temperatura);
x[i] += dx[i] / d * paso;
y[i] += dy[i] / d * paso;
}
}
temperatura *= enfriamiento;
}
empaquetarSubredes(comp, indice, x, y);
for (String id : ids) {
int i = indice.obtener(id);
posiciones.insertar(id, new double[]{x[i], y[i]});
}
}
private void empaquetarSubredes(ResultadoSubredes comp, TablaHash<Integer> indice, double[] x, double[] y) {
double separacion = LONGITUD_IDEAL * 2.5;
double cursorX = 0;
double cursorY = 0;
double altoMaximo = 0;
double anchoColumna = 0;
boolean primera = true;
for (Nodo<ListaEnlazada<String>> s = comp.getSubredes().getCabeza(); s != null; s = s.getSiguiente()) {
double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE;
double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
for (Nodo<String> v = s.getDato().getCabeza(); v != null; v = v.getSiguiente()) {
int i = indice.obtener(v.getDato());
minX = Math.min(minX, x[i]);
minY = Math.min(minY, y[i]);
maxX = Math.max(maxX, x[i]);
maxY = Math.max(maxY, y[i]);
}
double ancho = maxX - minX;
double alto = maxY - minY;
if (primera) {
altoMaximo = Math.max(alto, LONGITUD_IDEAL * 4);
cursorX = ancho + separacion;
primera = false;
desplazar(s.getDato(), indice, x, y, -minX, -minY);
continue;
}
if (cursorY > 0 && cursorY + alto > altoMaximo) {
cursorX += anchoColumna + separacion;
cursorY = 0;
anchoColumna = 0;
}
desplazar(s.getDato(), indice, x, y, cursorX - minX, cursorY - minY);
cursorY += alto + separacion;
anchoColumna = Math.max(anchoColumna, ancho);
}
}
private static void desplazar(ListaEnlazada<String> subred, TablaHash<Integer> indice, double[] x, double[] y, double dx, double dy) {
for (Nodo<String> v = subred.getCabeza(); v != null; v = v.getSiguiente()) {
int i = indice.obtener(v.getDato());
x[i] += dx;
y[i] += dy;
}
}
private void ubicarNueva(String id) {
double sumaX = 0;
double sumaY = 0;
int cuenta = 0;
for (Nodo<Arista> n = red.getGrafo().obtenerAdyacentes(id).getCabeza(); n != null; n = n.getSiguiente()) {
double[] p = posiciones.obtener(n.getDato().getDestino());
if (p != null) {
sumaX += p[0];
sumaY += p[1];
cuenta++;
}
}
double angulo = (id.hashCode() % 360) * Math.PI / 180;
if (cuenta > 0) {
posiciones.insertar(id, new double[]{
sumaX / cuenta + Math.cos(angulo) * LONGITUD_IDEAL * 0.8,
sumaY / cuenta + Math.sin(angulo) * LONGITUD_IDEAL * 0.8});
return;
}
double maxX = 0;
double minY = 0;
for (String otro : posiciones.claves()) {
double[] p = posiciones.obtener(otro);
maxX = Math.max(maxX, p[0]);
minY = Math.min(minY, p[1]);
}
posiciones.insertar(id, new double[]{maxX + LONGITUD_IDEAL, minY + LONGITUD_IDEAL * (posiciones.tamano() % 5)});
}
private String nodoEn(Point punto) {
if (red == null) {
return null;
}
String encontrado = null;
for (String id : red.getGrafo().obtenerVertices()) {
double[] p = posiciones.obtener(id);
if (p == null) {
continue;
}
double sx = p[0] * escala + desplazamientoX;
double sy = p[1] * escala + desplazamientoY;
double r = radioPantalla(id) + 3;
if ((punto.x - sx) * (punto.x - sx) + (punto.y - sy) * (punto.y - sy) <= r * r) {
encontrado = id;
}
}
return encontrado;
}
private double radio(String id) {
return RADIO_BASE + 2.5 * Math.min(6, red.getGrafo().grado(id));
}
private double radioPantalla(String id) {
return Math.max(5 + Math.min(3, red.getGrafo().grado(id)), radio(id) * escala);
}
private static String claveArista(String a, String b) {
return a.compareTo(b) < 0 ? a + "\u0000" + b : b + "\u0000" + a;
}
private Color colorNodo(String id) {
if (modoColor == ModoColor.POR_LINEA) {
Estacion e = red.obtenerEstacion(id);
Integer i = e == null ? null : colorLinea.obtener(e.getLinea());
return Tema.colorCategoria(i == null ? -1 : i);
}
return Tema.colorCategoria(subredes == null ? -1 : subredes.getIndiceSubred(id));
}
@Override
public String getToolTipText(MouseEvent e) {
String id = nodoEn(e.getPoint());
if (id == null) {
return null;
}
Estacion est = red.obtenerEstacion(id);
if (est == null) {
return null;
}
return "<html><b>" + Formato.html(est.getNombre()) + "</b> (" + Formato.html(id) + ")<br>"
+ "Línea: " + Formato.html(est.getLinea()) + "<br>"
+ "Zona: " + Formato.html(est.getZona()) + "<br>"
+ "Capacidad: " + est.getCapacidadPasajerosHora() + " pas/h<br>"
+ "Conexiones: " + red.getGrafo().grado(id) + "</html>";
}
@Override
protected void paintComponent(Graphics g) {
super.paintComponent(g);
Graphics2D g2 = (Graphics2D) g.create();
g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
dibujarCuadricula(g2);
if (red == null || red.getNumEstaciones() == 0) {
dibujarMensajeVacio(g2);
g2.dispose();
return;
}
if (ajustePendiente && getWidth() > 0) {
ajustePendiente = false;
ajustarVista();
}
dibujarAristas(g2);
dibujarNodos(g2);
dibujarLeyenda(g2);
g2.dispose();
}
private void dibujarCuadricula(Graphics2D g2) {
g2.setColor(new Color(0xF1F4F8));
int paso = 40;
for (int x = 0; x < getWidth(); x += paso) {
g2.drawLine(x, 0, x, getHeight());
}
for (int y = 0; y < getHeight(); y += paso) {
g2.drawLine(0, y, getWidth(), y);
}
}
private void dibujarMensajeVacio(Graphics2D g2) {
g2.setColor(Tema.TEXTO_SECUNDARIO);
g2.setFont(Tema.FUENTE_NEGRITA.deriveFont(16f));
String texto = "No hay estaciones cargadas";
FontMetrics fm = g2.getFontMetrics();
g2.drawString(texto, (getWidth() - fm.stringWidth(texto)) / 2, getHeight() / 2 - 10);
g2.setFont(Tema.FUENTE);
String sub = "Use \"Cargar archivo CSV\" o \"Agregar estación\" para comenzar.";
fm = g2.getFontMetrics();
g2.drawString(sub, (getWidth() - fm.stringWidth(sub)) / 2, getHeight() / 2 + 16);
}
private void dibujarAristas(Graphics2D g2) {
boolean mostrarPesos = escala >= 0.35;
Font fuentePeso = Tema.FUENTE_PEQUENA.deriveFont((float) Math.max(9, Math.min(13, 11 * escala)));
for (int pasada = 0; pasada < 2; pasada++) {
for (Nodo<Conexion> n = red.getGrafo().obtenerConexiones().getCabeza(); n != null; n = n.getSiguiente()) {
Conexion c = n.getDato();
boolean enRuta = aristasRuta.contiene(claveArista(c.getOrigen(), c.getDestino()));
if ((pasada == 0) == enRuta) {
continue;
}
double[] p1 = posiciones.obtener(c.getOrigen());
double[] p2 = posiciones.obtener(c.getDestino());
if (p1 == null || p2 == null) {
continue;
}
int x1 = (int) (p1[0] * escala + desplazamientoX);
int y1 = (int) (p1[1] * escala + desplazamientoY);
int x2 = (int) (p2[0] * escala + desplazamientoX);
int y2 = (int) (p2[1] * escala + desplazamientoY);
if (enRuta) {
g2.setColor(Tema.RUTA);
g2.setStroke(new BasicStroke((float) Math.max(4, 7 * escala), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
} else {
g2.setColor(Tema.ARISTA);
g2.setStroke(new BasicStroke((float) Math.max(1.5, 2.5 * escala)));
}
g2.drawLine(x1, y1, x2, y2);
if (mostrarPesos) {
String texto = Formato.minutos(c.getTiempo()) + "'";
g2.setFont(fuentePeso);
FontMetrics fm = g2.getFontMetrics();
int ancho = fm.stringWidth(texto) + 8;
int alto = fm.getHeight();
int mx = (x1 + x2) / 2 - ancho / 2;
int my = (y1 + y2) / 2 - alto / 2;
g2.setColor(enRuta ? Tema.RUTA : Color.WHITE);
g2.fillRoundRect(mx, my, ancho, alto, alto, alto);
g2.setColor(enRuta ? Color.WHITE : Tema.TEXTO_SECUNDARIO);
g2.drawString(texto, mx + 4, my + fm.getAscent());
}
}
}
}
private void dibujarNodos(Graphics2D g2) {
Font fuenteEtiqueta = Tema.FUENTE_NEGRITA.deriveFont((float) Math.max(10, Math.min(15, 12 * escala)));
boolean hayRuta = !nodosRuta.estaVacia();
for (String id : red.getGrafo().obtenerVertices()) {
double[] p = posiciones.obtener(id);
if (p == null) {
continue;
}
double r = radioPantalla(id);
int cx = (int) (p[0] * escala + desplazamientoX);
int cy = (int) (p[1] * escala + desplazamientoY);
int d = (int) (2 * r);
Color relleno = colorNodo(id);
if (hayRuta && !nodosRuta.contiene(id)) {
relleno = mezclar(relleno, Color.WHITE, 0.65);
}
if (nodosHub.contiene(id)) {
int anillo = (int) (r + Math.max(4, 6 * escala));
g2.setColor(Tema.HUB);
g2.setStroke(new BasicStroke((float) Math.max(3, 4 * escala)));
g2.drawOval(cx - anillo, cy - anillo, 2 * anillo, 2 * anillo);
}
g2.setColor(relleno);
g2.fillOval(cx - d / 2, cy - d / 2, d, d);
g2.setStroke(new BasicStroke(id.equals(seleccionada) ? 3.5f : 1.5f));
g2.setColor(id.equals(seleccionada) ? Tema.TEXTO : Tema.oscurecer(relleno));
g2.drawOval(cx - d / 2, cy - d / 2, d, d);
}
g2.setFont(fuenteEtiqueta);
FontMetrics fm = g2.getFontMetrics();
for (String id : red.getGrafo().obtenerVertices()) {
double[] p = posiciones.obtener(id);
if (p == null) {
continue;
}
double r = radioPantalla(id);
int cx = (int) (p[0] * escala + desplazamientoX);
int cy = (int) (p[1] * escala + desplazamientoY);
int ancho = fm.stringWidth(id);
int tx = cx - ancho / 2;
int ty = cy + (int) r + fm.getAscent() + 2;
g2.setColor(new Color(255, 255, 255, 210));
g2.fillRoundRect(tx - 3, ty - fm.getAscent(), ancho + 6, fm.getHeight(), 6, 6);
g2.setColor(Tema.TEXTO);
g2.drawString(id, tx, ty);
}
}
private void dibujarLeyenda(Graphics2D g2) {
g2.setFont(Tema.FUENTE_PEQUENA);
FontMetrics fm = g2.getFontMetrics();
int total;
String titulo;
if (modoColor == ModoColor.POR_LINEA) {
total = lineas.length;
titulo = "Líneas";
} else {
total = subredes == null ? 0 : subredes.getCantidad();
titulo = "Subredes conexas: " + total;
}
int visibles = Math.min(total, MAX_LEYENDA);
int filas = visibles + 1 + (total > visibles ? 1 : 0) + (nodosRuta.estaVacia() ? 0 : 1) + (nodosHub.estaVacia() ? 0 : 1);
int alto = filas * 18 + 14;
int ancho = 200;
int x0 = 12;
int y0 = 12;
g2.setColor(new Color(255, 255, 255, 230));
g2.fillRoundRect(x0, y0, ancho, alto, 12, 12);
g2.setColor(Tema.BORDE);
g2.setStroke(new BasicStroke(1));
g2.drawRoundRect(x0, y0, ancho, alto, 12, 12);
int y = y0 + 20;
g2.setFont(Tema.FUENTE_NEGRITA.deriveFont(11f));
g2.setColor(Tema.TEXTO);
g2.drawString(titulo, x0 + 10, y);
g2.setFont(Tema.FUENTE_PEQUENA);
for (int i = 0; i < visibles; i++) {
y += 18;
String texto;
if (modoColor == ModoColor.POR_LINEA) {
texto = lineas[i];
} else {
int tam = subredes.getSubred(i).tamano();
texto = "Subred " + (i + 1) + " · " + tam + (tam == 1 ? " estación" : " estaciones");
}
g2.setColor(Tema.colorCategoria(i));
g2.fillOval(x0 + 10, y - 10, 11, 11);
g2.setColor(Tema.TEXTO);
g2.drawString(recortar(texto, fm, ancho - 40), x0 + 28, y);
}
if (total > visibles) {
y += 18;
g2.setColor(Tema.TEXTO_SECUNDARIO);
g2.drawString("… y " + (total - visibles) + " más", x0 + 28, y);
}
if (!nodosRuta.estaVacia()) {
y += 18;
g2.setColor(Tema.RUTA);
g2.setStroke(new BasicStroke(4, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
g2.drawLine(x0 + 10, y - 5, x0 + 21, y - 5);
g2.setColor(Tema.TEXTO);
g2.drawString("Ruta más rápida", x0 + 28, y);
}
if (!nodosHub.estaVacia()) {
y += 18;
g2.setColor(Tema.HUB);
g2.setStroke(new BasicStroke(2.5f));
g2.drawOval(x0 + 10, y - 11, 11, 11);
g2.setColor(Tema.TEXTO);
g2.drawString("Hub de transferencia", x0 + 28, y);
}
}
private static String recortar(String texto, FontMetrics fm, int ancho) {
if (fm.stringWidth(texto) <= ancho) {
return texto;
}
String t = texto;
while (t.length() > 1 && fm.stringWidth(t + "…") > ancho) {
t = t.substring(0, t.length() - 1);
}
return t + "…";
}
private static Color mezclar(Color a, Color b, double proporcion) {
double q = 1 - proporcion;
return new Color((int) (a.getRed() * q + b.getRed() * proporcion),
(int) (a.getGreen() * q + b.getGreen() * proporcion),
(int) (a.getBlue() * q + b.getBlue() * proporcion));
}
}
