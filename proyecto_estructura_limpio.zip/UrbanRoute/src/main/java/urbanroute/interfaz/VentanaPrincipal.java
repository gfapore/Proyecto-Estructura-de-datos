package urbanroute.interfaz;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileNameExtensionFilter;
import urbanroute.algoritmos.AnalizadorRed;
import urbanroute.algoritmos.InfoGrado;
import urbanroute.algoritmos.ResultadoRuta;
import urbanroute.estructuras.Arista;
import urbanroute.estructuras.Conexion;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.estructuras.Nodo;
import urbanroute.modelo.Estacion;
import urbanroute.modelo.Formato;
import urbanroute.modelo.RedTransporte;
import urbanroute.persistencia.GestorArchivo;
import urbanroute.persistencia.ResultadoCarga;
public class VentanaPrincipal extends JFrame {
private static final String RUTA_MAESTRO = "datos" + File.separator + "metro_caracas.csv";
private static final String RECURSO_MAESTRO = "/urbanroute/datos/metro_caracas.csv";
private final GestorArchivo gestorArchivo = new GestorArchivo();
private RedTransporte red = new RedTransporte();
private File archivoActual;
private boolean cambiosSinGuardar;
private String rutaOrigen;
private String rutaDestino;
private final PanelGrafo panelGrafo = new PanelGrafo();
private final JEditorPane panelResultados = new JEditorPane();
private final JLabel etiquetaArchivo = new JLabel();
private final JLabel etiquetaTotales = new JLabel();
private final JTextField campoBusqueda = new JTextField();
public VentanaPrincipal() {
super("UrbanRoute");
setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
addWindowListener(new WindowAdapter() {
@Override
public void windowClosing(WindowEvent e) {
salir();
}
});
setMinimumSize(new Dimension(1100, 680));
setSize(1440, 900);
setLocationRelativeTo(null);
JPanel raiz = new JPanel(new BorderLayout());
raiz.setBackground(Tema.FONDO);
raiz.add(crearEncabezado(), BorderLayout.NORTH);
raiz.add(crearBarraLateral(), BorderLayout.WEST);
raiz.add(crearCentro(), BorderLayout.CENTER);
raiz.add(crearPanelResultados(), BorderLayout.EAST);
raiz.add(crearBarraEstado(), BorderLayout.SOUTH);
setContentPane(raiz);
setJMenuBar(crearMenu());
panelGrafo.setOyenteSeleccion(id -> mostrar(GeneradorInformes.fichaEstacion(red, id, panelGrafo.getSubredes())));
panelGrafo.setRed(red);
mostrar(GeneradorInformes.bienvenida());
actualizarEstado();
}
private JPanel crearEncabezado() {
JPanel panel = new JPanel(new BorderLayout());
panel.setBackground(Color.WHITE);
panel.setBorder(BorderFactory.createCompoundBorder(
BorderFactory.createMatteBorder(0, 0, 1, 0, Tema.BORDE),
BorderFactory.createEmptyBorder(10, 18, 10, 18)));
JLabel titulo = new JLabel("UrbanRoute");
titulo.setFont(Tema.FUENTE_TITULO);
titulo.setForeground(Tema.TEXTO);
JLabel sub = new JLabel("Optimización y análisis de redes de transporte multimodal");
sub.setFont(Tema.FUENTE);
sub.setForeground(Tema.TEXTO_SECUNDARIO);
JPanel textos = new JPanel(new BorderLayout(0, 2));
textos.setOpaque(false);
textos.add(titulo, BorderLayout.NORTH);
textos.add(sub, BorderLayout.SOUTH);
panel.add(textos, BorderLayout.WEST);
JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 6));
busqueda.setOpaque(false);
JLabel lupa = new JLabel("Buscar estación (ID o nombre):");
lupa.setFont(Tema.FUENTE);
campoBusqueda.setColumns(16);
campoBusqueda.setFont(Tema.FUENTE);
campoBusqueda.setToolTipText("Escriba el ID (ej. PZA_VZLA) o el nombre (ej. Plaza Venezuela) y presione Enter");
campoBusqueda.addActionListener(e -> buscarEstacion());
JButton ir = new BotonPlano("Buscar", Tema.ACENTO, Tema.ACENTO_HOVER, Color.WHITE, "Buscar en la tabla hash");
ir.addActionListener(e -> buscarEstacion());
busqueda.add(lupa);
busqueda.add(campoBusqueda);
busqueda.add(ir);
panel.add(busqueda, BorderLayout.EAST);
return panel;
}
private JScrollPane crearBarraLateral() {
JPanel panel = new JPanel();
panel.setBackground(Tema.LATERAL);
panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
panel.setBorder(BorderFactory.createEmptyBorder(14, 12, 14, 12));
seccion(panel, "ARCHIVO");
boton(panel, "Cargar archivo CSV…", "Abrir un archivo de la red con JFileChooser", e -> cargarArchivo());
boton(panel, "Actualizar repositorio", "Guardar los cambios en el archivo fuente", e -> actualizarRepositorio());
boton(panel, "Guardar como…", "Guardar la red en otro archivo", e -> guardarComo());
seccion(panel, "MODIFICAR RED");
boton(panel, "Agregar estación", "Registrar una estación nueva con sus conexiones", e -> agregarEstacion());
boton(panel, "Agregar conexión", "Conectar dos estaciones o cambiar el tiempo de una conexión", e -> agregarConexion());
botonPeligro(panel, "Eliminar conexión", "Quitar la conexión entre dos estaciones", e -> eliminarConexion());
botonPeligro(panel, "Cerrar estación", "Eliminar una estación (cierre por mantenimiento o falla)", e -> eliminarEstacion());
seccion(panel, "ANÁLISIS");
boton(panel, "Subredes conexas (BFS)", "Detectar las zonas que quedan conectadas entre sí", e -> mostrarSubredes(null));
boton(panel, "Ruta más rápida (Dijkstra)", "Calcular el trayecto de menor tiempo entre dos estaciones", e -> calcularRuta());
boton(panel, "Hubs de transferencia", "Estaciones con mayor número de conexiones directas", e -> mostrarHubs());
boton(panel, "Limpiar resaltado", "Quitar la ruta y los hubs resaltados", e -> limpiarResaltado());
seccion(panel, "AYUDA");
boton(panel, "Cómo usar", "Instrucciones de uso", e -> mostrar(GeneradorInformes.bienvenida()));
boton(panel, "Tabla hash", "Estadísticas de la tabla hash de estaciones", e -> mostrar(GeneradorInformes.estadisticasHash(red)));
panel.add(Box.createVerticalGlue());
JScrollPane scroll = new JScrollPane(panel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
scroll.setBorder(null);
scroll.setPreferredSize(new Dimension(250, 0));
scroll.getVerticalScrollBar().setUnitIncrement(16);
return scroll;
}
private JPanel crearCentro() {
JPanel centro = new JPanel(new BorderLayout());
centro.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 0));
centro.setOpaque(false);
JPanel herramientas = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
herramientas.setBackground(Color.WHITE);
herramientas.setBorder(BorderFactory.createMatteBorder(1, 1, 0, 1, Tema.BORDE));
JComboBox<PanelGrafo.ModoColor> modo = new JComboBox<>(PanelGrafo.ModoColor.values());
modo.setFont(Tema.FUENTE);
modo.setToolTipText("Identificar visualmente las subredes o las líneas de transporte");
modo.addActionListener(e -> panelGrafo.setModoColor((PanelGrafo.ModoColor) modo.getSelectedItem()));
herramientas.add(modo);
herramientas.add(botonHerramienta("Ajustar vista", "Ver toda la red", e -> panelGrafo.ajustarVista()));
herramientas.add(botonHerramienta("+", "Acercar", e -> panelGrafo.aplicarZoom(1.25, panelGrafo.getWidth() / 2.0, panelGrafo.getHeight() / 2.0)));
herramientas.add(botonHerramienta("−", "Alejar", e -> panelGrafo.aplicarZoom(0.8, panelGrafo.getWidth() / 2.0, panelGrafo.getHeight() / 2.0)));
herramientas.add(botonHerramienta("Redistribuir", "Recalcular la posición de todas las estaciones", e -> panelGrafo.redistribuir()));
JLabel ayuda = new JLabel("Rueda: zoom · Arrastrar: mover · Clic: ver estación");
ayuda.setFont(Tema.FUENTE_PEQUENA);
ayuda.setForeground(Tema.TEXTO_SECUNDARIO);
herramientas.add(ayuda);
panelGrafo.setBorder(BorderFactory.createLineBorder(Tema.BORDE));
centro.add(herramientas, BorderLayout.NORTH);
centro.add(panelGrafo, BorderLayout.CENTER);
return centro;
}
private JPanel crearPanelResultados() {
panelResultados.setContentType("text/html");
panelResultados.setEditable(false);
panelResultados.setBackground(Color.WHITE);
JScrollPane scroll = new JScrollPane(panelResultados);
scroll.setBorder(BorderFactory.createLineBorder(Tema.BORDE));
scroll.getVerticalScrollBar().setUnitIncrement(16);
JPanel panel = new JPanel(new BorderLayout());
panel.setOpaque(false);
panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
panel.setPreferredSize(new Dimension(340, 0));
panel.add(scroll, BorderLayout.CENTER);
return panel;
}
private JPanel crearBarraEstado() {
JPanel panel = new JPanel(new BorderLayout());
panel.setBackground(Color.WHITE);
panel.setBorder(BorderFactory.createCompoundBorder(
BorderFactory.createMatteBorder(1, 0, 0, 0, Tema.BORDE),
BorderFactory.createEmptyBorder(5, 14, 5, 14)));
etiquetaArchivo.setFont(Tema.FUENTE_PEQUENA);
etiquetaArchivo.setForeground(Tema.TEXTO_SECUNDARIO);
etiquetaTotales.setFont(Tema.FUENTE_PEQUENA);
etiquetaTotales.setForeground(Tema.TEXTO_SECUNDARIO);
panel.add(etiquetaArchivo, BorderLayout.WEST);
panel.add(etiquetaTotales, BorderLayout.EAST);
return panel;
}
private JMenuBar crearMenu() {
JMenuBar barra = new JMenuBar();
JMenu archivo = new JMenu("Archivo");
archivo.add(item("Cargar archivo CSV…", KeyEvent.VK_O, e -> cargarArchivo()));
archivo.add(item("Actualizar repositorio", KeyEvent.VK_S, e -> actualizarRepositorio()));
archivo.add(item("Guardar como…", 0, e -> guardarComo()));
archivo.addSeparator();
archivo.add(item("Salir", 0, e -> salir()));
JMenu redMenu = new JMenu("Red");
redMenu.add(item("Agregar estación", 0, e -> agregarEstacion()));
redMenu.add(item("Agregar conexión", 0, e -> agregarConexion()));
redMenu.add(item("Eliminar conexión", 0, e -> eliminarConexion()));
redMenu.add(item("Cerrar estación", 0, e -> eliminarEstacion()));
JMenu analisis = new JMenu("Análisis");
analisis.add(item("Subredes conexas (BFS)", 0, e -> mostrarSubredes(null)));
analisis.add(item("Ruta más rápida (Dijkstra)", KeyEvent.VK_R, e -> calcularRuta()));
analisis.add(item("Hubs de transferencia", 0, e -> mostrarHubs()));
analisis.add(item("Limpiar resaltado", 0, e -> limpiarResaltado()));
JMenu ayuda = new JMenu("Ayuda");
ayuda.add(item("Cómo usar", 0, e -> mostrar(GeneradorInformes.bienvenida())));
ayuda.add(item("Estadísticas de la tabla hash", 0, e -> mostrar(GeneradorInformes.estadisticasHash(red))));
ayuda.add(item("Acerca de", 0, e -> JOptionPane.showMessageDialog(this,
"UrbanRoute 1.0\nAnálisis de redes de transporte multimodal.\n\n"
+ "Grafo ponderado (lista de adyacencia) y tabla hash propios.\n"
+ "Algoritmos: BFS, Dijkstra y centralidad de grado.\n\n"
+ "Estructuras de Datos — Universidad Metropolitana",
"Acerca de UrbanRoute", JOptionPane.INFORMATION_MESSAGE)));
barra.add(archivo);
barra.add(redMenu);
barra.add(analisis);
barra.add(ayuda);
return barra;
}
private static void seccion(JPanel panel, String texto) {
if (panel.getComponentCount() > 0) {
panel.add(Box.createVerticalStrut(14));
}
JLabel etiqueta = new JLabel(texto);
etiqueta.setFont(Tema.FUENTE_NEGRITA.deriveFont(11f));
etiqueta.setForeground(Tema.LATERAL_TITULO);
etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
etiqueta.setBorder(BorderFactory.createEmptyBorder(0, 4, 6, 0));
etiqueta.setMaximumSize(new Dimension(Integer.MAX_VALUE, etiqueta.getPreferredSize().height));
panel.add(etiqueta);
}
private static void boton(JPanel panel, String texto, String ayuda, java.awt.event.ActionListener accion) {
agregarBoton(panel, new BotonPlano(texto, Tema.LATERAL_BOTON, Tema.LATERAL_BOTON_HOVER, Tema.LATERAL_TEXTO, ayuda), accion);
}
private static void botonPeligro(JPanel panel, String texto, String ayuda, java.awt.event.ActionListener accion) {
agregarBoton(panel, new BotonPlano(texto, Tema.LATERAL_BOTON, Tema.PELIGRO_HOVER, new Color(0xFFB4B4), ayuda), accion);
}
private static void agregarBoton(JPanel panel, JButton b, java.awt.event.ActionListener accion) {
b.setAlignmentX(Component.LEFT_ALIGNMENT);
b.addActionListener(accion);
panel.add(b);
panel.add(Box.createVerticalStrut(5));
}
private static JButton botonHerramienta(String texto, String ayuda, java.awt.event.ActionListener accion) {
BotonPlano b = new BotonPlano(texto, new Color(0xEEF2F7), new Color(0xDDE5EF), Tema.TEXTO, ayuda);
b.setHorizontalAlignment(JLabel.CENTER);
b.setMargin(new java.awt.Insets(5, 10, 5, 10));
b.addActionListener(accion);
return b;
}
private static JMenuItem item(String texto, int tecla, java.awt.event.ActionListener accion) {
JMenuItem item = new JMenuItem(texto);
if (tecla != 0) {
item.setAccelerator(KeyStroke.getKeyStroke(tecla, java.awt.event.InputEvent.CTRL_DOWN_MASK));
}
item.addActionListener(accion);
return item;
}
public void cargarArchivoMaestro() {
File maestro = new File(System.getProperty("user.dir"), RUTA_MAESTRO);
try {
if (!maestro.isFile()) {
try (InputStream entrada = VentanaPrincipal.class.getResourceAsStream(RECURSO_MAESTRO)) {
if (entrada == null) {
throw new IOException("No se encontró el archivo maestro.");
}
File carpeta = maestro.getParentFile();
if (carpeta != null) {
carpeta.mkdirs();
}
Files.copy(entrada, maestro.toPath(), StandardCopyOption.REPLACE_EXISTING);
}
}
cargarDesde(maestro, false);
} catch (IOException ex) {
JOptionPane.showMessageDialog(this,
"No se pudo cargar el archivo maestro:\n" + ex.getMessage()
+ "\n\nPuede cargar otro archivo con \"Cargar archivo CSV\".",
"Archivo maestro", JOptionPane.WARNING_MESSAGE);
}
}
private void cargarArchivo() {
if (red.getNumEstaciones() > 0) {
String detalle = cambiosSinGuardar
? "Hay cambios SIN GUARDAR en la red actual."
: "La red actual no tiene cambios pendientes.";
int r = JOptionPane.showConfirmDialog(this,
"Al cargar un archivo nuevo se reemplazarán los datos en memoria.\n" + detalle
+ "\n\n¿Desea guardar los datos actuales antes de continuar?",
"Guardar antes de cargar", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
if (r == JOptionPane.CANCEL_OPTION || r == JOptionPane.CLOSED_OPTION) {
return;
}
if (r == JOptionPane.YES_OPTION && !actualizarRepositorio()) {
return;
}
}
JFileChooser selector = crearSelector();
selector.setDialogTitle("Cargar red de transporte");
if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
return;
}
try {
cargarDesde(selector.getSelectedFile(), true);
} catch (IOException ex) {
JOptionPane.showMessageDialog(this, "No se pudo cargar el archivo:\n" + ex.getMessage()
+ "\n\nLos datos en memoria no se modificaron.", "Error al cargar", JOptionPane.ERROR_MESSAGE);
}
}
private void cargarDesde(File archivo, boolean informar) throws IOException {
ResultadoCarga carga = gestorArchivo.cargar(archivo);
red = carga.getRed();
archivoActual = archivo;
cambiosSinGuardar = false;
rutaOrigen = null;
rutaDestino = null;
panelGrafo.setRed(red);
actualizarEstado();
mostrarSubredes("Archivo cargado: " + archivo.getName() + " (" + red.getNumEstaciones()
+ " estaciones, " + red.getNumConexiones() + " conexiones).");
ListaEnlazada<String> avisos = carga.getAdvertencias();
if (!avisos.estaVacia()) {
StringBuilder sb = new StringBuilder("Se cargó el archivo, pero algunas líneas se omitieron o corrigieron:\n\n");
int mostrados = 0;
for (Nodo<String> n = avisos.getCabeza(); n != null && mostrados < 15; n = n.getSiguiente(), mostrados++) {
sb.append("• ").append(n.getDato()).append('\n');
}
if (avisos.tamano() > mostrados) {
sb.append("… y ").append(avisos.tamano() - mostrados).append(" advertencias más.");
}
JOptionPane.showMessageDialog(this, sb.toString(), "Advertencias de carga", JOptionPane.WARNING_MESSAGE);
} else if (informar) {
JOptionPane.showMessageDialog(this, "Archivo cargado correctamente.\n" + red.getNumEstaciones()
+ " estaciones y " + red.getNumConexiones() + " conexiones.", "Carga completa",
JOptionPane.INFORMATION_MESSAGE);
}
}
private boolean actualizarRepositorio() {
if (archivoActual == null) {
return guardarComo();
}
return guardarEn(archivoActual, true);
}
private boolean guardarComo() {
JFileChooser selector = crearSelector();
selector.setDialogTitle("Guardar red de transporte");
if (archivoActual != null) {
selector.setSelectedFile(archivoActual);
}
if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
return false;
}
File destino = selector.getSelectedFile();
if (!destino.getName().toLowerCase().endsWith(".csv")) {
destino = new File(destino.getParentFile(), destino.getName() + ".csv");
}
if (destino.exists() && !destino.equals(archivoActual)) {
int r = JOptionPane.showConfirmDialog(this, "El archivo " + destino.getName() + " ya existe.\n¿Desea reemplazarlo?",
"Confirmar reemplazo", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
if (r != JOptionPane.YES_OPTION) {
return false;
}
}
if (guardarEn(destino, true)) {
archivoActual = destino;
actualizarEstado();
return true;
}
return false;
}
private boolean guardarEn(File archivo, boolean informar) {
try {
gestorArchivo.guardar(red, archivo);
cambiosSinGuardar = false;
actualizarEstado();
if (informar) {
JOptionPane.showMessageDialog(this, "Repositorio actualizado:\n" + archivo.getAbsolutePath(),
"Guardado", JOptionPane.INFORMATION_MESSAGE);
}
return true;
} catch (IOException | RuntimeException ex) {
JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo:\n" + ex.getMessage(),
"Error al guardar", JOptionPane.ERROR_MESSAGE);
return false;
}
}
private JFileChooser crearSelector() {
File carpeta = archivoActual != null ? archivoActual.getAbsoluteFile().getParentFile()
: new File(System.getProperty("user.dir"));
JFileChooser selector = new JFileChooser(carpeta);
selector.setFileFilter(new FileNameExtensionFilter("Archivos CSV / texto (*.csv, *.txt)", "csv", "txt"));
return selector;
}
private void salir() {
if (cambiosSinGuardar) {
int r = JOptionPane.showConfirmDialog(this,
"Hay cambios sin guardar en la red.\n¿Desea actualizar el repositorio antes de salir?",
"Salir", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
if (r == JOptionPane.CANCEL_OPTION || r == JOptionPane.CLOSED_OPTION) {
return;
}
if (r == JOptionPane.YES_OPTION && !actualizarRepositorio()) {
return;
}
}
dispose();
System.exit(0);
}
private void agregarEstacion() {
DialogoNuevaEstacion dialogo = new DialogoNuevaEstacion(this, red);
Estacion nueva = dialogo.mostrar();
if (nueva == null) {
return;
}
if (!red.agregarEstacion(nueva)) {
Dialogos.error(this, "No se pudo agregar la estación: el ID ya existe.");
return;
}
int agregadas = 0;
for (Nodo<Arista> n = dialogo.getConexiones().getCabeza(); n != null; n = n.getSiguiente()) {
if (red.existeId(n.getDato().getDestino())) {
red.agregarConexion(nueva.getId(), n.getDato().getDestino(), n.getDato().getTiempo());
agregadas++;
}
}
trasModificacion("Se agregó la estación " + nueva + " con " + agregadas
+ (agregadas == 1 ? " conexión." : " conexiones."));
panelGrafo.seleccionarYCentrar(nueva.getId());
}
private void agregarConexion() {
if (red.getNumEstaciones() < 2) {
Dialogos.error(this, "Se necesitan al menos dos estaciones para crear una conexión.");
return;
}
Conexion c = Dialogos.pedirNuevaConexion(this, red, red.obtenerEstacionesOrdenadas());
if (c == null) {
return;
}
try {
boolean nueva = red.agregarConexion(c.getOrigen(), c.getDestino(), c.getTiempo());
trasModificacion((nueva ? "Se agregó la conexión " : "Se actualizó la conexión ")
+ c.getOrigen() + " — " + c.getDestino() + " (" + Formato.minutos(c.getTiempo()) + " min).");
} catch (IllegalArgumentException ex) {
Dialogos.error(this, ex.getMessage());
}
}
private void eliminarConexion() {
if (red.getNumConexiones() == 0) {
Dialogos.error(this, "La red no tiene conexiones para eliminar.");
return;
}
Estacion[] todas = red.obtenerEstacionesOrdenadas();
int conGrado = 0;
for (Estacion e : todas) {
if (red.getGrafo().grado(e.getId()) > 0) {
conGrado++;
}
}
Estacion[] conectadas = new Estacion[conGrado];
int k = 0;
for (Estacion e : todas) {
if (red.getGrafo().grado(e.getId()) > 0) {
conectadas[k++] = e;
}
}
Conexion c = Dialogos.pedirConexionAEliminar(this, red, conectadas);
if (c == null) {
return;
}
int r = JOptionPane.showConfirmDialog(this, "¿Eliminar la conexión " + c.getOrigen() + " — " + c.getDestino() + "?",
"Confirmar", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
if (r == JOptionPane.YES_OPTION && red.eliminarConexion(c.getOrigen(), c.getDestino())) {
trasModificacion("Se eliminó la conexión " + c.getOrigen() + " — " + c.getDestino() + ".");
}
}
private void eliminarEstacion() {
if (red.getNumEstaciones() == 0) {
Dialogos.error(this, "No hay estaciones en la red.");
return;
}
Estacion e = Dialogos.elegirEstacion(this, "Cerrar estación", "Estación a cerrar:", red.obtenerEstacionesOrdenadas());
if (e == null) {
return;
}
int grado = red.getGrafo().grado(e.getId());
int antes = AnalizadorRed.detectarSubredes(red.getGrafo()).getCantidad();
int despues = AnalizadorRed.subredesTrasCierre(red.getGrafo(), e.getId());
int r = JOptionPane.showConfirmDialog(this,
"Se cerrará la estación " + e + " y sus " + grado + " conexiones.\n"
+ "La red pasará de " + antes + " a " + despues + " subredes.\n\n¿Desea continuar?",
"Confirmar cierre", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
if (r == JOptionPane.YES_OPTION && red.eliminarEstacion(e.getId()) != null) {
trasModificacion("Se cerró la estación " + e + ". La red pasó de " + antes + " a " + despues + " subredes.");
}
}
private void trasModificacion(String descripcion) {
cambiosSinGuardar = true;
panelGrafo.actualizarRed();
actualizarEstado();
if (rutaOrigen != null && red.existeId(rutaOrigen) && red.existeId(rutaDestino)) {
mostrarRuta(rutaOrigen, rutaDestino, descripcion + " Ruta recalculada.");
} else {
if (rutaOrigen != null) {
descripcion += " La ruta consultada ya no es válida porque una de sus estaciones fue cerrada.";
rutaOrigen = null;
rutaDestino = null;
}
panelGrafo.limpiarResaltados();
mostrarSubredes(descripcion);
}
}
private void mostrarSubredes(String aviso) {
mostrar(GeneradorInformes.subredes(red, AnalizadorRed.detectarSubredes(red.getGrafo()), aviso));
}
private void calcularRuta() {
if (red.getNumEstaciones() < 2) {
Dialogos.error(this, "Se necesitan al menos dos estaciones para calcular una ruta.");
return;
}
String[] od = Dialogos.pedirOrigenDestino(this, red.obtenerEstacionesOrdenadas(), rutaOrigen, rutaDestino);
if (od != null) {
mostrarRuta(od[0], od[1], null);
}
}
private void mostrarRuta(String origen, String destino, String aviso) {
ResultadoRuta ruta = AnalizadorRed.rutaMasRapida(red.getGrafo(), origen, destino);
rutaOrigen = origen;
rutaDestino = destino;
panelGrafo.resaltarHubs(new String[0]);
panelGrafo.resaltarRuta(ruta.existeRuta() ? ruta.getCamino() : null);
mostrar(GeneradorInformes.ruta(red, ruta, aviso));
}
private void mostrarHubs() {
InfoGrado[] ranking = AnalizadorRed.calcularCentralidadGrado(red.getGrafo());
String[] hubs = AnalizadorRed.obtenerHubs(ranking);
rutaOrigen = null;
rutaDestino = null;
panelGrafo.resaltarRuta(null);
panelGrafo.resaltarHubs(hubs);
mostrar(GeneradorInformes.hubs(red, ranking, hubs));
}
private void limpiarResaltado() {
rutaOrigen = null;
rutaDestino = null;
panelGrafo.limpiarResaltados();
}
private void buscarEstacion() {
String texto = campoBusqueda.getText();
if (texto.trim().isEmpty()) {
Dialogos.error(this, "Escriba el ID o el nombre de la estación a buscar.");
return;
}
Estacion e = red.buscarEstacion(texto);
if (e == null) {
Dialogos.error(this, "No existe ninguna estación con el ID o nombre \"" + texto.trim() + "\".");
return;
}
panelGrafo.seleccionarYCentrar(e.getId());
mostrar(GeneradorInformes.fichaEstacion(red, e.getId(), panelGrafo.getSubredes()));
}
private void mostrar(String html) {
panelResultados.setText(html.replace(" <b>", "&nbsp;<b>"));
SwingUtilities.invokeLater(() -> panelResultados.setCaretPosition(0));
}
private void actualizarEstado() {
String nombre = archivoActual == null ? "(sin archivo)" : archivoActual.getName();
setTitle("UrbanRoute — " + nombre + (cambiosSinGuardar ? " *" : ""));
etiquetaArchivo.setText("Archivo: " + (archivoActual == null ? "ninguno" : archivoActual.getAbsolutePath())
+ (cambiosSinGuardar ? "   •   cambios sin guardar" : ""));
etiquetaArchivo.setForeground(cambiosSinGuardar ? Tema.PELIGRO : Tema.TEXTO_SECUNDARIO);
int subredes = panelGrafo.getSubredes() == null ? 0 : panelGrafo.getSubredes().getCantidad();
etiquetaTotales.setText(red.getNumEstaciones() + " estaciones   ·   " + red.getNumConexiones()
+ " conexiones   ·   " + subredes + " subredes");
}
}
