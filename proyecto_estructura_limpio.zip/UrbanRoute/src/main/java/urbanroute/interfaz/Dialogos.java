package urbanroute.interfaz;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import urbanroute.estructuras.Conexion;
import urbanroute.estructuras.ListaEnlazada;
import urbanroute.estructuras.Nodo;
import urbanroute.modelo.Estacion;
import urbanroute.modelo.Formato;
import urbanroute.modelo.RedTransporte;
public final class Dialogos {
private Dialogos() {
}
public static Estacion elegirEstacion(Component padre, String titulo, String mensaje, Estacion[] estaciones) {
JComboBox<Estacion> combo = new JComboBox<>(estaciones);
JPanel panel = formulario(new String[]{mensaje}, new JComponent[]{combo});
int opcion = JOptionPane.showConfirmDialog(padre, panel, titulo, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
return opcion == JOptionPane.OK_OPTION ? (Estacion) combo.getSelectedItem() : null;
}
public static Conexion pedirNuevaConexion(Component padre, RedTransporte red, Estacion[] estaciones) {
JComboBox<Estacion> origen = new JComboBox<>(estaciones);
JComboBox<Estacion> destino = new JComboBox<>(estaciones);
if (estaciones.length > 1) {
destino.setSelectedIndex(1);
}
JSpinner tiempo = new JSpinner(new SpinnerNumberModel(2.0, 0.5, 999.0, 0.5));
JPanel panel = formulario(new String[]{"Estación A:", "Estación B:", "Tiempo de traslado (min):"},
new JComponent[]{origen, destino, tiempo});
while (true) {
int opcion = JOptionPane.showConfirmDialog(padre, panel, "Agregar conexión",
JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
if (opcion != JOptionPane.OK_OPTION) {
return null;
}
Estacion a = (Estacion) origen.getSelectedItem();
Estacion b = (Estacion) destino.getSelectedItem();
double minutos = ((Number) tiempo.getValue()).doubleValue();
if (a == null || b == null) {
return null;
}
if (a.equals(b)) {
error(padre, "Una estación no puede conectarse consigo misma.\nElija dos estaciones distintas.");
continue;
}
if (red.getGrafo().existeArista(a.getId(), b.getId())) {
double actual = red.getGrafo().buscarArista(a.getId(), b.getId()).getTiempo();
int r = JOptionPane.showConfirmDialog(padre,
"La conexión " + a.getId() + " — " + b.getId() + " ya existe (" + Formato.minutos(actual)
+ " min).\n¿Desea cambiar su tiempo a " + Formato.minutos(minutos) + " min?",
"Conexión existente", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
if (r != JOptionPane.YES_OPTION) {
continue;
}
}
return new Conexion(a.getId(), b.getId(), minutos);
}
}
public static Conexion pedirConexionAEliminar(Component padre, RedTransporte red, Estacion[] estaciones) {
JComboBox<Estacion> origen = new JComboBox<>(estaciones);
JComboBox<Estacion> destino = new JComboBox<>();
Runnable actualizarDestino = () -> {
destino.removeAllItems();
Estacion o = (Estacion) origen.getSelectedItem();
if (o != null) {
ListaEnlazada<Estacion> vecinas = red.obtenerVecinas(o.getId());
for (Nodo<Estacion> n = vecinas.getCabeza(); n != null; n = n.getSiguiente()) {
destino.addItem(n.getDato());
}
}
};
origen.addActionListener(e -> actualizarDestino.run());
actualizarDestino.run();
JPanel panel = formulario(new String[]{"Estación A:", "Conectada con:"}, new JComponent[]{origen, destino});
int opcion = JOptionPane.showConfirmDialog(padre, panel, "Eliminar conexión",
JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
Estacion a = (Estacion) origen.getSelectedItem();
Estacion b = (Estacion) destino.getSelectedItem();
if (opcion != JOptionPane.OK_OPTION || a == null || b == null) {
return null;
}
return new Conexion(a.getId(), b.getId(), 0);
}
public static String[] pedirOrigenDestino(Component padre, Estacion[] estaciones, String origenPrevio, String destinoPrevio) {
JComboBox<Estacion> origen = new JComboBox<>(estaciones);
JComboBox<Estacion> destino = new JComboBox<>(estaciones);
seleccionar(origen, origenPrevio, 0);
seleccionar(destino, destinoPrevio, estaciones.length - 1);
JPanel panel = formulario(new String[]{"Estación A (origen):", "Estación B (destino):"},
new JComponent[]{origen, destino});
while (true) {
int opcion = JOptionPane.showConfirmDialog(padre, panel, "Ruta de menor tiempo",
JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
if (opcion != JOptionPane.OK_OPTION) {
return null;
}
Estacion a = (Estacion) origen.getSelectedItem();
Estacion b = (Estacion) destino.getSelectedItem();
if (a == null || b == null) {
return null;
}
if (a.equals(b)) {
error(padre, "El origen y el destino deben ser estaciones distintas.");
continue;
}
return new String[]{a.getId(), b.getId()};
}
}
public static void error(Component padre, String mensaje) {
JOptionPane.showMessageDialog(padre, mensaje, "Dato no válido", JOptionPane.WARNING_MESSAGE);
}
private static void seleccionar(JComboBox<Estacion> combo, String id, int porDefecto) {
for (int i = 0; i < combo.getItemCount(); i++) {
if (combo.getItemAt(i).getId().equals(id)) {
combo.setSelectedIndex(i);
return;
}
}
if (porDefecto >= 0 && porDefecto < combo.getItemCount()) {
combo.setSelectedIndex(porDefecto);
}
}
static JPanel formulario(String[] etiquetas, JComponent[] campos) {
JPanel panel = new JPanel(new GridBagLayout());
GridBagConstraints c = new GridBagConstraints();
c.insets = new Insets(5, 5, 5, 5);
c.anchor = GridBagConstraints.WEST;
for (int i = 0; i < campos.length; i++) {
c.gridx = 0;
c.gridy = i;
c.weightx = 0;
c.fill = GridBagConstraints.NONE;
JLabel etiqueta = new JLabel(etiquetas[i]);
etiqueta.setFont(Tema.FUENTE);
panel.add(etiqueta, c);
c.gridx = 1;
c.weightx = 1;
c.fill = GridBagConstraints.HORIZONTAL;
campos[i].setFont(Tema.FUENTE);
panel.add(campos[i], c);
}
return panel;
}
}
