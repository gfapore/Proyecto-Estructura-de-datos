package urbanroute.interfaz;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import javax.swing.JButton;
import javax.swing.SwingConstants;
public class BotonPlano extends JButton {
private final Color fondo;
private final Color fondoHover;
public BotonPlano(String texto, Color fondo, Color fondoHover, Color colorTexto, String ayuda) {
super(texto);
this.fondo = fondo;
this.fondoHover = fondoHover;
setForeground(colorTexto);
setFont(Tema.FUENTE);
setToolTipText(ayuda);
setContentAreaFilled(false);
setBorderPainted(false);
setFocusPainted(false);
setOpaque(false);
setRolloverEnabled(true);
setHorizontalAlignment(SwingConstants.LEFT);
setMargin(new Insets(8, 14, 8, 14));
setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
}
@Override
public Dimension getMaximumSize() {
return new Dimension(Integer.MAX_VALUE, getPreferredSize().height);
}
@Override
protected void paintComponent(Graphics g) {
Graphics2D g2 = (Graphics2D) g.create();
g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
Color color = fondo;
if (!isEnabled()) {
color = fondo.darker();
} else if (getModel().isPressed()) {
color = fondoHover.darker();
} else if (getModel().isRollover()) {
color = fondoHover;
}
g2.setColor(color);
g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
g2.dispose();
super.paintComponent(g);
}
}
