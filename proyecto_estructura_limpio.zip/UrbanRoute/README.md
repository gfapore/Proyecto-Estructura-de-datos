# UrbanRoute — Optimización y Análisis de Redes de Transporte Multimodal

UrbanRoute modela una red de transporte urbano (por ejemplo, el Metro de Caracas) como un **grafo ponderado no dirigido** cuyas estaciones se indexan en una **tabla hash propia**. Con él se puede visualizar la red, modificarla (agregar o cerrar estaciones y conexiones), detectar las subredes aisladas (BFS), calcular la ruta de menor tiempo (Dijkstra) e identificar los hubs de transferencia (centralidad de grado).

## Integrantes

- Nombre Apellido — carné
- Nombre Apellido — carné
- Nombre Apellido — carné

## Repositorio

https://github.com/USUARIO/UrbanRoute

## Cómo ejecutar

1. Abrir la carpeta `UrbanRoute` en NetBeans (*File → Open Project*). Es un proyecto Maven y no usa librerías externas.
2. Ejecutar con *Run Project* (F6). La clase principal es `urbanroute.UrbanRoute`.
3. Al iniciar se carga automáticamente el archivo maestro `datos/metro_caracas.csv`.

## Formato de los archivos

El programa acepta los dos formatos del enunciado, por separado o en un mismo archivo:

```
ID_Estacion,Nombre,Linea,Zona,Capacidad_Pasajeros_Hora
PRO,Propatria,Linea 1,Catia,12000

Estacion_Origen,Estacion_Destino,Tiempo_Minutos
PRO,PER,2
```

Si un archivo solo trae conexiones, las estaciones se crean con nombre igual a su ID. *Actualizar repositorio* guarda ambas secciones en el archivo fuente para que, al volver a cargarlo, la red quede igual.

## Estructura del código

| Paquete | Contenido |
|---|---|
| `urbanroute.estructuras` | TDAs propios: `Grafo`, `TablaHash`, `ListaEnlazada`, `Cola`, `ColaPrioridad`, `Ordenamiento` |
| `urbanroute.modelo` | `Estacion` y `RedTransporte` (mantiene sincronizados grafo y tabla hash) |
| `urbanroute.algoritmos` | `AnalizadorRed`: BFS, Dijkstra, centralidad de grado y simulación de cierres |
| `urbanroute.persistencia` | `GestorArchivo`: lectura y escritura de CSV |
| `urbanroute.interfaz` | Ventana Swing, dibujo del grafo y diálogos |

No se usa el Java Collections Framework para los TDA. El diagrama de clases está en `docs/DiagramaClases.md`.

## Funcionalidades adicionales

- Búsqueda de estaciones por ID o nombre en O(1) usando la tabla hash.
- Simulación del impacto de un cierre: antes de cerrar una estación o al ver los hubs se indica en cuántas subredes quedaría dividida la red.
- Recalculo automático de la última ruta consultada después de cada modificación.
- Coloreado del grafo por subred o por línea, zoom, desplazamiento y nodos arrastrables.
- Estadísticas de la tabla hash (factor de carga, colisiones, cadena más larga).
- Lectura tolerante de archivos (UTF-8 o Windows-1252) con reporte de líneas inválidas.
