# Diagrama de clases — UrbanRoute

Diagrama en formato Mermaid (se ve renderizado en GitHub o en https://mermaid.live).

```mermaid
classDiagram
    direction LR

    class Nodo~T~ {
        -T dato
        -Nodo~T~ siguiente
    }
    class ListaEnlazada~T~ {
        -Nodo~T~ cabeza
        -Nodo~T~ cola
        -int tamano
        +agregar(T)
        +agregarAlInicio(T)
        +obtener(int) T
        +buscar(Condicion) T
        +eliminarPrimero(Condicion) boolean
        +tamano() int
    }
    class Cola~T~ {
        +encolar(T)
        +desencolar() T
        +estaVacia() boolean
    }
    class ColaPrioridad {
        -String[] claves
        -double[] prioridades
        +insertar(String, double)
        +extraerMinimo() String
        +prioridadMinima() double
    }
    class EntradaHash~V~ {
        ~String clave
        ~V valor
        ~EntradaHash~V~ siguiente
    }
    class TablaHash~V~ {
        -EntradaHash~V~[] cubetas
        -int tamano
        -funcionHash(String, int) int
        +insertar(String, V)
        +obtener(String) V
        +contiene(String) boolean
        +eliminar(String) V
        +claves() String[]
        -redimensionar()
    }
    class Arista {
        -String destino
        -double tiempo
    }
    class Conexion {
        -String origen
        -String destino
        -double tiempo
    }
    class Grafo {
        -TablaHash~ListaEnlazada~Arista~~ listaAdyacencia
        -ListaEnlazada~String~ vertices
        -int numAristas
        +agregarVertice(String) boolean
        +eliminarVertice(String) boolean
        +agregarArista(String, String, double) boolean
        +eliminarArista(String, String) boolean
        +obtenerAdyacentes(String) ListaEnlazada~Arista~
        +grado(String) int
        +obtenerConexiones() ListaEnlazada~Conexion~
    }
    class Ordenamiento {
        +mergeSort(T[], Comparador)$
    }

    class Estacion {
        -String id
        -String nombre
        -String linea
        -String zona
        -int capacidadPasajerosHora
        +crearGenerica(String)$ Estacion
    }
    class RedTransporte {
        -Grafo grafo
        -TablaHash~Estacion~ estacionesPorId
        -TablaHash~Estacion~ estacionesPorNombre
        +agregarEstacion(Estacion) boolean
        +eliminarEstacion(String) Estacion
        +agregarConexion(String, String, double) boolean
        +eliminarConexion(String, String) boolean
        +buscarEstacion(String) Estacion
    }

    class AnalizadorRed {
        +detectarSubredes(Grafo)$ ResultadoSubredes
        +rutaMasRapida(Grafo, String, String)$ ResultadoRuta
        +calcularCentralidadGrado(Grafo)$ InfoGrado[]
        +obtenerHubs(InfoGrado[])$ String[]
        +subredesTrasCierre(Grafo, String)$ int
    }
    class ResultadoSubredes
    class ResultadoRuta
    class InfoGrado

    class GestorArchivo {
        +cargar(File) ResultadoCarga
        +guardar(RedTransporte, File)
    }
    class ResultadoCarga

    class UrbanRoute {
        +main(String[])$
    }
    class VentanaPrincipal
    class PanelGrafo
    class DialogoNuevaEstacion
    class Dialogos
    class GeneradorInformes

    ListaEnlazada o-- Nodo
    Cola o-- Nodo
    TablaHash o-- EntradaHash
    Grafo *-- TablaHash
    Grafo *-- ListaEnlazada
    Grafo ..> Arista
    Grafo ..> Conexion
    RedTransporte *-- Grafo
    RedTransporte *-- TablaHash
    RedTransporte o-- Estacion
    AnalizadorRed ..> Grafo
    AnalizadorRed ..> Cola : BFS
    AnalizadorRed ..> ColaPrioridad : Dijkstra
    AnalizadorRed ..> ResultadoSubredes
    AnalizadorRed ..> ResultadoRuta
    AnalizadorRed ..> InfoGrado
    GestorArchivo ..> RedTransporte
    GestorArchivo ..> ResultadoCarga
    UrbanRoute ..> VentanaPrincipal
    VentanaPrincipal *-- PanelGrafo
    VentanaPrincipal --> RedTransporte
    VentanaPrincipal --> GestorArchivo
    VentanaPrincipal ..> AnalizadorRed
    VentanaPrincipal ..> DialogoNuevaEstacion
    VentanaPrincipal ..> Dialogos
    VentanaPrincipal ..> GeneradorInformes
    PanelGrafo --> RedTransporte
```

## Responsabilidades (resumen tipo CRC)

| Clase | Responsabilidad | Colabora con |
|---|---|---|
| `TablaHash` | Indexar objetos por clave en O(1) promedio (hash polinomial, encadenamiento, rehash) | `EntradaHash` |
| `Grafo` | Topología: vértices, aristas ponderadas, grado y adyacencias | `TablaHash`, `ListaEnlazada`, `Arista` |
| `Estacion` | Datos descriptivos de una parada | — |
| `RedTransporte` | Mantener sincronizados grafo y tabla hash en toda alta o baja; búsquedas por ID o nombre | `Grafo`, `TablaHash`, `Estacion` |
| `AnalizadorRed` | BFS (subredes), Dijkstra (ruta óptima), centralidad de grado (hubs) | `Grafo`, `Cola`, `ColaPrioridad` |
| `GestorArchivo` | Leer y escribir el CSV, validando cada línea | `RedTransporte` |
| `VentanaPrincipal` | Coordinar acciones del usuario y mostrar resultados | `RedTransporte`, `GestorArchivo`, `AnalizadorRed`, `PanelGrafo` |
| `PanelGrafo` | Dibujar el grafo y resaltar subredes, rutas y hubs | `RedTransporte`, `AnalizadorRed` |
